# Room/Retrofit/Media3/Coil supply consumer rules. JSON is parsed explicitly.
-keepattributes Signature,InnerClasses,EnclosingMethod
