plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
 id("org.jetbrains.kotlin.plugin.compose")
 id("org.jetbrains.kotlin.kapt")
}
android {
 namespace = "com.svara.lite"
 compileSdk = 36
 defaultConfig {
  applicationId = "com.svara.lite"
  minSdk = 26
  targetSdk = 36
  versionCode = 1
  versionName = "1.0"
  testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  buildConfigField("String", "UPDATE_URL", "\"${providers.gradleProperty("UPDATE_URL").orElse("").get()}\"")
 }
 signingConfigs {
  create("release") {
   val path = System.getenv("SVARA_KEYSTORE")
   if (!path.isNullOrBlank()) {
    storeFile = file(path)
    storePassword = System.getenv("SVARA_STORE_PASSWORD")
    keyAlias = System.getenv("SVARA_KEY_ALIAS") ?: "svara"
    keyPassword = System.getenv("SVARA_KEY_PASSWORD")
   }
  }
 }
 buildTypes {
  debug { applicationIdSuffix = ".debug"; versionNameSuffix = "-debug" }
  release {
   isMinifyEnabled = true
   isShrinkResources = true
   signingConfig = signingConfigs.getByName("release")
   proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
  }
 }
 buildFeatures { compose = true; buildConfig = true }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17"; freeCompilerArgs += "-opt-in=androidx.media3.common.util.UnstableApi" }
 packaging { resources.excludes += setOf("META-INF/AL2.0", "META-INF/LGPL2.1") }
}
kapt { arguments { arg("room.schemaLocation", "$projectDir/schemas") } }
dependencies {
 implementation(platform("androidx.compose:compose-bom:2025.04.01"))
 implementation("androidx.activity:activity-compose:1.10.1")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.compose.material:material-icons-core")
 implementation("androidx.compose.ui:ui-tooling-preview")
 debugImplementation("androidx.compose.ui:ui-tooling")
 implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.0")
 implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.0")
 implementation("androidx.core:core-ktx:1.16.0")
 implementation("androidx.media3:media3-exoplayer:1.6.1")
 implementation("androidx.media3:media3-session:1.6.1")
 implementation("androidx.media3:media3-datasource-okhttp:1.6.1")
 implementation("androidx.media3:media3-database:1.6.1")
 implementation("androidx.room:room-runtime:2.7.1")
 implementation("androidx.room:room-ktx:2.7.1")
 kapt("androidx.room:room-compiler:2.7.1")
 implementation("androidx.work:work-runtime-ktx:2.10.1")
 implementation("com.squareup.retrofit2:retrofit:2.11.0")
 implementation("com.squareup.okhttp3:okhttp:4.12.0")
 implementation("io.coil-kt:coil-compose:2.7.0")
 testImplementation("junit:junit:4.13.2")
}
// Never silently sign a release with a debug key.
tasks.matching { it.name == "validateSigningRelease" }.configureEach {
 doFirst { check(!System.getenv("SVARA_KEYSTORE").isNullOrBlank()) { "Set SVARA_KEYSTORE and signing password environment variables. See README." } }
}
