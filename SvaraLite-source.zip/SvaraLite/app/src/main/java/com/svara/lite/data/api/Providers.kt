package com.svara.lite.data.api
import com.svara.lite.domain.model.Song
import com.svara.lite.data.repository.Settings
import okhttp3.ResponseBody
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.QueryMap
import retrofit2.http.Url
interface JsonApi { @GET suspend fun get(@Url url:String,@QueryMap query:Map<String,String>):ResponseBody }
private fun JSONObject.str(k:String)=optString(k,"").takeUnless { it=="null" } ?: ""
private fun https(s:String):String = if(s.startsWith("https://")) s else ""
private fun JSONObject.rows(key:String):List<JSONObject> { val a=optJSONArray(key)?:return emptyList();return (0 until a.length()).mapNotNull { a.optJSONObject(it) } }
class JamendoProvider(private val api:JsonApi,private val settings:Settings):MusicProvider {
 override val name="Jamendo"
 private suspend fun tracks(extra:Map<String,String>):List<Song> {
  check(settings.jamendoId.isNotBlank()) { "Add your free Jamendo client ID in Settings." }
  val params=mapOf("client_id" to settings.jamendoId,"format" to "json","limit" to "40","audioformat" to "mp31","audiodlformat" to "mp31","imagesize" to "200","type" to "single albumtrack")+extra
  val root=api.get("https://api.jamendo.com/v3.0/tracks/",params).use { JSONObject(it.string()) }
  check(root.optJSONObject("headers")?.optString("status")=="success") { "Jamendo: check your client ID or try again later." }
  return root.rows("results").map { o ->
   val url=https(o.str("audiodownload"))
   Song(id="Jamendo:${o.str("id")}",title=o.str("name"),artist=o.str("artist_name"),artwork=https(o.str("image")),duration=o.optLong("duration"),streamUrl=https(o.str("audio")),downloadUrl=url.takeIf { it.isNotEmpty() },downloadAllowed=o.optBoolean("audiodownload_allowed",false)&&url.isNotEmpty(),source=name,pageUrl=https(o.str("shareurl")),license=o.str("license_ccurl"))
  }.filter { it.streamUrl.isNotBlank() }
 }
 override suspend fun search(query:String,genre:Boolean)=tracks(if(genre)mapOf("tags" to query) else mapOf("search" to query))
 override suspend fun resolve(song:Song)=tracks(mapOf("id" to song.id.substringAfter(':'))).firstOrNull() ?: error("Track unavailable")
}
class AudiusProvider(private val api:JsonApi,private val settings:Settings):MusicProvider {
 override val name="Audius"
 private val base="https://api.audius.co/v1"
 private fun params()=mutableMapOf("app_name" to "SvaraLite").apply { if(settings.audiusKey.isNotBlank())put("api_key",settings.audiusKey) }
 private fun parse(o:JSONObject):Song? {
  if(o.optBoolean("is_stream_gated") || o.optBoolean("is_unlisted") || o.optBoolean("is_delete"))return null
  val id=o.str("id");if(id.isBlank())return null
  // Fail closed: gated/conditional Audius downloads are never offered.
  val dm=o.optJSONObject("download")
  val downloadable=dm!=null && dm.optBoolean("is_downloadable",false) && !dm.optBoolean("requires_follow",true) && !o.optBoolean("is_download_gated",true) && o.isNull("download_conditions")
  val query=okhttp3.HttpUrl.Builder().scheme("https").host("api.audius.co").addPathSegments("v1/tracks/$id/stream").apply { params().forEach{(k,v)->addQueryParameter(k,v)} }.build().toString()
  val download=query.replace("/stream?","/download?")
  return Song("Audius:$id",o.str("title"),o.optJSONObject("user")?.str("name")?:"Unknown artist",https(o.optJSONObject("artwork")?.str("150x150")?:""),o.optLong("duration"),query,download.takeIf{downloadable},downloadable,name,"https://audius.co${o.str("permalink")}")
 }
 override suspend fun search(query:String,genre:Boolean):List<Song> {
  val p=params().apply { put("limit","40");put(if(genre) "genre" else "query",query) }
  return api.get("$base/tracks/search",p).use { JSONObject(it.string()).rows("data").mapNotNull(::parse) }
 }
 override suspend fun resolve(song:Song):Song = api.get("$base/tracks/${song.id.substringAfter(':')}",params()).use { JSONObject(it.string()).rows("data").firstNotNullOfOrNull(::parse)?:error("Track unavailable or restricted") }
}
