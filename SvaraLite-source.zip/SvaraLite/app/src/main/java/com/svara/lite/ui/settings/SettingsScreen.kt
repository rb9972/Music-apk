package com.svara.lite.ui.settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.svara.lite.ui.*
import com.svara.lite.BuildConfig
import com.svara.lite.domain.model.StoragePolicy
@Composable fun SettingsScreen(vm:MusicViewModel){
 val stats by vm.storage.collectAsStateWithLifecycle()
 var limit by remember{mutableIntStateOf(vm.settings.limitMb)};var custom by remember{mutableStateOf(limit.toString())}
 var cache by remember{mutableIntStateOf(vm.settings.cacheMb)};var quality by remember{mutableIntStateOf(vm.settings.bitrate)}
 var cleanup by remember{mutableStateOf(vm.settings.autoCleanup)};var confirmCleanup by remember{mutableStateOf(false)};var confirmDelete by remember{mutableStateOf(false)}
 var jamendo by remember{mutableStateOf(vm.settings.jamendoId)};var audius by remember{mutableStateOf(vm.settings.audiusKey)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom=24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Heading("Keep it light","Storage & preferences")
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
   Text("Phone available: ${bytes(stats.free)}")
   Text("App storage estimate: ${bytes(stats.app)}")
   Text("Downloaded music: ${bytes(stats.downloads)}")
   Text("Cache + artwork: ${bytes(stats.cache)}")
   Text("Temporary conversion files: ${bytes(stats.temporary)}")
   Text("App storage includes the APK and accessible app files. Android's Settings may show a larger installed total.",color=Muted,style=MaterialTheme.typography.bodySmall)
   TextButton(onClick=vm::refreshStorage){Text("Refresh")}
  }}
  Text("Download budget",style=MaterialTheme.typography.titleMedium)
  Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(25,50,75,100).forEach{m->FilterChip(selected=limit==m,onClick={limit=m;custom=m.toString();vm.settings.limitMb=m},label={Text("$m MB")})}}
  Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(value=custom,onValueChange={custom=it.filter(Char::isDigit).take(4)},modifier=Modifier.weight(1f),label={Text("Custom MB (1–1000)")},singleLine=true);TextButton(onClick={custom.toIntOrNull()?.takeIf{it in 1..1000}?.let{limit=it;vm.settings.limitMb=it}?:run{vm.notice.value="Enter 1–1000 MB"}}){Text("Apply")}}
  if(stats.downloads>limit*1_000_000L)Text("Existing downloads exceed this budget. Delete some songs; new downloads are blocked until there is room.",color=Amber)
  Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Automatic cleanup");Text("Delete oldest downloads when space is needed",style=MaterialTheme.typography.bodySmall,color=Muted)};Switch(checked=cleanup,onCheckedChange={if(it)confirmCleanup=true else {cleanup=false;vm.settings.autoCleanup=false}})}
  Text("Streaming cache",style=MaterialTheme.typography.titleMedium)
  Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(0,10,20,30).forEach{m->FilterChip(selected=cache==m,onClick={cache=m;vm.setCache(m)},label={Text(if(m==0)"Off" else "$m MB")})}}
  Text("Artwork cache: 2 MB disk / 4 MB memory. Older stream data is evicted automatically.",color=Muted,style=MaterialTheme.typography.bodySmall)
  Row{OutlinedButton(onClick=vm::clearCache){Text("Clear cache")};TextButton(onClick={confirmDelete=true}){Text("Delete all downloads")}}
  Text("Default offline quality",style=MaterialTheme.typography.titleMedium)
  Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){StoragePolicy.bitrates.forEach{k->FilterChip(selected=quality==k,onClick={quality=k;vm.settings.bitrate=k},label={Text("$k kbps")})}}
  HorizontalDivider()
  Heading("Music providers","Use your own free application credentials")
  OutlinedTextField(value=jamendo,onValueChange={jamendo=it},label={Text("Jamendo client ID")},singleLine=true,modifier=Modifier.fillMaxWidth())
  Text("Get a client ID at devportal.jamendo.com. Jamendo stays disabled until you add one.",color=Muted,style=MaterialTheme.typography.bodySmall)
  OutlinedTextField(value=audius,onValueChange={audius=it},label={Text("Audius API key (if required)")},singleLine=true,modifier=Modifier.fillMaxWidth())
  Text("Public app key only. Never enter a developer secret. No paid plan is required by this app.",color=Muted,style=MaterialTheme.typography.bodySmall)
  Button(onClick={vm.settings.jamendoId=jamendo;vm.settings.audiusKey=audius;vm.notice.value="Provider settings saved"}){Text("Save provider settings")}
  HorizontalDivider()
  Text("Svara Lite ${BuildConfig.VERSION_NAME}",style=MaterialTheme.typography.titleMedium)
  Text("Personal music player. No tracking SDKs, ads, or bundled music. Audius and Jamendo provide independent catalogs, not every mainstream release.",color=Muted)
  OutlinedButton(onClick={vm.checkUpdate()}){Text("Check for updates")}
 }
 if(confirmCleanup)AlertDialog(onDismissRequest={confirmCleanup=false},title={Text("Allow automatic deletion?")},text={Text("When a download needs room, Svara will delete the oldest downloaded audio, including favorites. Playlist and favorite metadata stays. You can turn this off anytime.")},confirmButton={TextButton(onClick={cleanup=true;vm.settings.autoCleanup=true;confirmCleanup=false}){Text("Allow cleanup")}},dismissButton={TextButton(onClick={confirmCleanup=false}){Text("Cancel")}})
 if(confirmDelete)AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Delete all downloaded audio?")},text={Text("Queued downloads will be cancelled. Device music, favorites, and playlists are kept.")},confirmButton={TextButton(onClick={vm.deleteAll();confirmDelete=false}){Text("Delete all")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("Cancel")}})
}
