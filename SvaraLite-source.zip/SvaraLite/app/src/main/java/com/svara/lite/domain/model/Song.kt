package com.svara.lite.domain.model
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "songs")
data class Song(
 @PrimaryKey val id: String,
 val title: String,
 val artist: String,
 val artwork: String = "",
 val duration: Long = 0,
 val streamUrl: String = "",
 val downloadUrl: String? = null,
 val downloadAllowed: Boolean = false,
 val source: String,
 val pageUrl: String = "",
 val license: String = "",
 val favorite: Boolean = false,
 val savedAt: Long = System.currentTimeMillis()
)
object StoragePolicy {
 const val MB = 1_000_000L
 const val RESERVE = 20 * MB
 val bitrates = listOf(32, 48, 64, 96)
 fun estimate(seconds: Long, kbps: Int): Long = ((seconds.coerceAtLeast(0) * kbps * 1000L / 8) * 1.03).toLong()
 fun fits(used: Long, incoming: Long, limit: Long) = incoming >= 0 && used <= limit - incoming
}
