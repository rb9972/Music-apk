package com.svara.lite.downloads
import android.media.*
import com.svara.lite.domain.model.StoragePolicy
import java.io.File
// Uses the phone's codecs, so no FFmpeg/native codec bundle is shipped.
object AacEncoder {
 fun encode(input:File,output:File,kbps:Int,maxBytes:Long,checkActive:()->Unit):Int {
  val extractor=MediaExtractor()
  var decoder:MediaCodec?=null
  var encoder:MediaCodec?=null
  var muxer:MediaMuxer?=null
  var muxStarted=false
  var muxTrack=-1
  var written=0L
  var encoderDone=false
  var lastProgress=System.nanoTime()
  try {
   extractor.setDataSource(input.absolutePath)
   val index=(0 until extractor.trackCount).firstOrNull { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/")==true } ?: error("The source did not return audio")
   extractor.selectTrack(index)
   val format=extractor.getTrackFormat(index)
   check(!format.containsKey("crypto-key")) { "Protected audio is not supported" }
   format.setInteger(MediaFormat.KEY_PCM_ENCODING,android.media.AudioFormat.ENCODING_PCM_16BIT)
   val dec=MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
   decoder=dec;dec.configure(format,null,null,0);dec.start()
   muxer=MediaMuxer(output.absolutePath,MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
   var inputDone=false
   var decoderDone=false
   var rate=44100
   var channels=2
   val decoded=MediaCodec.BufferInfo()
   val encoded=MediaCodec.BufferInfo()
   fun drainEncoder(wait:Long=0) {
    val enc=encoder?:return
    var n=enc.dequeueOutputBuffer(encoded,wait)
    while(n!=MediaCodec.INFO_TRY_AGAIN_LATER) {
     if(n==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { check(!muxStarted);muxTrack=muxer!!.addTrack(enc.outputFormat);muxer!!.start();muxStarted=true }
     else if(n>=0) {
      if(encoded.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG==0 && encoded.size>0) {
       check(muxStarted);check(written+encoded.size<=maxBytes && output.parentFile!!.usableSpace>StoragePolicy.RESERVE) { "Storage limit reached during conversion" }
       val b=enc.getOutputBuffer(n)!!;b.position(encoded.offset);b.limit(encoded.offset+encoded.size)
       muxer!!.writeSampleData(muxTrack,b,encoded);written+=encoded.size
      }
      encoderDone=encoded.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0
      enc.releaseOutputBuffer(n,false);lastProgress=System.nanoTime()
     }
     n=enc.dequeueOutputBuffer(encoded,0)
    }
   }
   while(!encoderDone) {
    checkActive()
    check(System.nanoTime()-lastProgress<30_000_000_000L) { "Audio conversion stalled on this device" }
    if(!inputDone) {
     val i=dec.dequeueInputBuffer(10_000)
     if(i>=0) {
      val b=dec.getInputBuffer(i)!!
      val size=extractor.readSampleData(b,0)
      if(size<0) { dec.queueInputBuffer(i,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true }
      else { check(extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_ENCRYPTED==0) { "Encrypted audio is not supported" };dec.queueInputBuffer(i,0,size,extractor.sampleTime,0);extractor.advance() }
     }
    }
    if(!decoderDone) {
     val n=dec.dequeueOutputBuffer(decoded,10_000)
     if(n==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED && encoder==null) {
      val pcm=dec.outputFormat
      rate=pcm.getInteger(MediaFormat.KEY_SAMPLE_RATE);channels=pcm.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
      check(channels in 1..2) { "Only mono/stereo conversion is supported" }
      if(pcm.containsKey(MediaFormat.KEY_PCM_ENCODING))check(pcm.getInteger(MediaFormat.KEY_PCM_ENCODING)==android.media.AudioFormat.ENCODING_PCM_16BIT) { "Unsupported PCM format" }
      val ef=MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,rate,channels)
      ef.setInteger(MediaFormat.KEY_AAC_PROFILE,MediaCodecInfo.CodecProfileLevel.AACObjectLC)
      ef.setInteger(MediaFormat.KEY_BIT_RATE,kbps*1000)
      ef.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE,65536)
      encoder=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).also { it.configure(ef,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);it.start() }
     } else if(n>=0) {
      val enc=encoder?:error("No PCM format received")
      val pcm=dec.getOutputBuffer(n)!!;pcm.position(decoded.offset);pcm.limit(decoded.offset+decoded.size)
      var consumed=0
      while(pcm.hasRemaining()) {
       checkActive();drainEncoder()
       val i=enc.dequeueInputBuffer(10_000)
       if(i>=0) {
        val b=enc.getInputBuffer(i)!!;b.clear()
        val frame=channels*2;val count=minOf(b.remaining(),pcm.remaining())/frame*frame;check(count>0){"Unaligned PCM buffer"};val oldLimit=pcm.limit();pcm.limit(pcm.position()+count);b.put(pcm);pcm.limit(oldLimit)
        val pts=decoded.presentationTimeUs+consumed.toLong()*1_000_000/(rate*channels*2)
        enc.queueInputBuffer(i,0,count,pts,0);consumed+=count;lastProgress=System.nanoTime()
       }
       check(System.nanoTime()-lastProgress<30_000_000_000L) { "Encoder stalled" }
      }
      decoderDone=decoded.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0
      if(decoderDone) {
       var sent=false
       while(!sent){checkActive();check(System.nanoTime()-lastProgress<30_000_000_000L){"Encoder stalled at end of stream"};drainEncoder();val i=enc.dequeueInputBuffer(10_000);if(i>=0){enc.queueInputBuffer(i,0,0,decoded.presentationTimeUs,MediaCodec.BUFFER_FLAG_END_OF_STREAM);sent=true}}
      }
      dec.releaseOutputBuffer(n,false);lastProgress=System.nanoTime()
     }
    }
    drainEncoder(10_000)
   }
   check(written>0) { "Empty audio output" }
   muxer!!.stop();muxStarted=false
   val mr=MediaMetadataRetriever()
   return try { mr.setDataSource(output.absolutePath);(mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull()?.div(1000))?:kbps } finally { mr.release() }
  } finally {
   runCatching { decoder?.stop() };decoder?.release()
   runCatching { encoder?.stop() };encoder?.release()
   if(muxStarted)runCatching { muxer?.stop() };muxer?.release();extractor.release()
  }
 }
}
