package com.svara.lite.player
import android.content.Context
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.cache.*
import com.svara.lite.data.repository.Settings
import com.svara.lite.domain.model.Song
import java.util.TreeSet
// A mutable LRU limit: changing cache settings does not create a second SimpleCache.
class AdjustableEvictor(private val limit:()->Long):CacheEvictor {
 private val spans=TreeSet<CacheSpan>(compareBy<CacheSpan>{it.lastTouchTimestamp}.thenBy{it.key}.thenBy{it.position})
 private var used=0L
 override fun requiresCacheSpanTouches()=true
 override fun onCacheInitialized() {}
 override fun onStartFile(cache:Cache,key:String,position:Long,length:Long) { trim(cache,length.coerceAtLeast(0)) }
 override fun onSpanAdded(cache:Cache,span:CacheSpan) { spans.add(span);used+=span.length;trim(cache) }
 override fun onSpanRemoved(cache:Cache,span:CacheSpan) { if(spans.remove(span))used-=span.length }
 override fun onSpanTouched(cache:Cache,oldSpan:CacheSpan,newSpan:CacheSpan) { onSpanRemoved(cache,oldSpan);onSpanAdded(cache,newSpan) }
 fun trim(cache:Cache,incoming:Long=0) { while(used+incoming>limit() && spans.isNotEmpty())cache.removeSpan(spans.first()) }
}
class StreamCache(context:Context,settings:Settings) {
 private val evictor=AdjustableEvictor { settings.cacheMb*1_000_000L }
 val store=SimpleCache(context.cacheDir.resolve("stream"),evictor,StandaloneDatabaseProvider(context))
 fun resize()=synchronized(store) { evictor.trim(store) }
 fun clear() { store.keys.toList().forEach { store.removeResource(it) } }
 fun complete(song:Song):Boolean {
  val length=ContentMetadata.getContentLength(store.getContentMetadata(song.id))
  return length>0 && store.isCached(song.id,0,length)
 }
}
