package com.svara.lite.data.database
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import com.svara.lite.domain.model.Song
@Entity(tableName="downloads", foreignKeys=[ForeignKey(entity=Song::class,parentColumns=["id"],childColumns=["songId"],onDelete=ForeignKey.CASCADE)])
data class Download(@PrimaryKey val songId:String, val path:String, val bytes:Long, val kbps:Int, val createdAt:Long=System.currentTimeMillis())
@Entity(tableName="playlists")
data class Playlist(@PrimaryKey(autoGenerate=true) val id:Long=0, val name:String)
@Entity(tableName="playlist_songs", primaryKeys=["playlistId","songId"], indices=[Index("songId")], foreignKeys=[ForeignKey(entity=Playlist::class,parentColumns=["id"],childColumns=["playlistId"],onDelete=ForeignKey.CASCADE),ForeignKey(entity=Song::class,parentColumns=["id"],childColumns=["songId"],onDelete=ForeignKey.CASCADE)])
data class PlaylistSong(val playlistId:Long,val songId:String,val addedAt:Long=System.currentTimeMillis())
@Dao
interface MusicDao {
 @Query("SELECT * FROM songs ORDER BY savedAt DESC") fun songs():Flow<List<Song>>
 @Query("SELECT * FROM songs WHERE id=:id") suspend fun song(id:String):Song?
 @Insert(onConflict=OnConflictStrategy.IGNORE) suspend fun insert(song:Song)
 @Query("UPDATE songs SET title=:title,artist=:artist,artwork=:artwork,duration=:duration,streamUrl=:stream,downloadUrl=:download,downloadAllowed=:allowed,license=:license,pageUrl=:page WHERE id=:id") suspend fun refresh(id:String,title:String,artist:String,artwork:String,duration:Long,stream:String,download:String?,allowed:Boolean,license:String,page:String)
 @Transaction suspend fun save(song:Song) { insert(song); refresh(song.id,song.title,song.artist,song.artwork,song.duration,song.streamUrl,song.downloadUrl,song.downloadAllowed,song.license,song.pageUrl) }
 @Query("UPDATE songs SET favorite = NOT favorite WHERE id=:id") suspend fun favorite(id:String)
 @Query("SELECT * FROM downloads ORDER BY createdAt ASC") fun downloads():Flow<List<Download>>
 @Query("SELECT * FROM downloads ORDER BY createdAt ASC") suspend fun allDownloads():List<Download>
 @Query("SELECT * FROM downloads WHERE songId=:id") suspend fun download(id:String):Download?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun saveDownload(download:Download)
 @Query("DELETE FROM downloads WHERE songId=:id") suspend fun deleteDownload(id:String)
 @Query("SELECT * FROM playlists ORDER BY name") fun playlists():Flow<List<Playlist>>
 @Insert suspend fun createPlaylist(playlist:Playlist):Long
 @Query("UPDATE playlists SET name=:name WHERE id=:id") suspend fun renamePlaylist(id:Long,name:String)
 @Query("DELETE FROM playlists WHERE id=:id") suspend fun deletePlaylist(id:Long)
 @Insert(onConflict=OnConflictStrategy.IGNORE) suspend fun addToPlaylist(link:PlaylistSong)
 @Query("DELETE FROM playlist_songs WHERE playlistId=:playlist AND songId=:song") suspend fun removeFromPlaylist(playlist:Long,song:String)
 @Query("SELECT * FROM playlist_songs ORDER BY addedAt") fun links():Flow<List<PlaylistSong>>
}
@Database(entities=[Song::class,Download::class,Playlist::class,PlaylistSong::class],version=1,exportSchema=true)
abstract class MusicDatabase:RoomDatabase() { abstract fun dao():MusicDao }
