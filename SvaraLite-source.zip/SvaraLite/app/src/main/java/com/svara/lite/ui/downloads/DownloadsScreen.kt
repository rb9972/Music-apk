package com.svara.lite.ui.downloads
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.svara.lite.ui.*
import com.svara.lite.domain.model.Song
import java.text.DateFormat
import java.util.Date
@Composable fun DownloadsScreen(vm:MusicViewModel,add:(Song)->Unit){
 val songs by vm.songs.collectAsStateWithLifecycle();val downloads by vm.downloads.collectAsStateWithLifecycle();val work by vm.work.collectAsStateWithLifecycle()
 var sort by remember{mutableStateOf("Newest")};var deleting by remember{mutableStateOf<String?>(null)}
 val sorted=when(sort){"Size"->downloads.sortedByDescending{it.bytes};"Oldest"->downloads.sortedBy{it.createdAt};else->downloads.sortedByDescending{it.createdAt}}
 val queue=sorted.mapNotNull{d->songs.firstOrNull{it.id==d.songId}}
 LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=24.dp)){
  item{Heading("Downloaded songs","${bytes(downloads.sumOf{it.bytes})} of ${vm.settings.limitMb} MB · one file per song")}
  item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Newest","Oldest","Size").forEach{s->FilterChip(selected=sort==s,onClick={sort=s},label={Text(s)})}}}
  val active=work.filter{!it.state.isFinished}
  items(active,key={it.id.toString()}){w->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){
   val id=w.tags.firstOrNull{it.startsWith("song:")}?.removePrefix("song:")
   Text(songs.firstOrNull{it.id==id}?.title?:"Download")
   Text(w.progress.getString("phase")?:"Waiting for network and free storage",color=Muted)
   LinearProgressIndicator(Modifier.fillMaxWidth().padding(top=8.dp))
   TextButton(onClick={WorkManager.getInstance(vm.app).cancelWorkById(w.id)}){Text("Cancel")}
  }}}
  val failures=work.filter{it.state==WorkInfo.State.FAILED}
  if(failures.isNotEmpty())item{Card{Column(Modifier.padding(14.dp)){Text("Download needs attention",color=Amber);failures.takeLast(3).forEach{Text(it.outputData.getString("error")?:"Download failed")};TextButton(onClick={WorkManager.getInstance(vm.app).pruneWork()}){Text("Dismiss completed tasks")}}}}
  if(sorted.isEmpty()&&active.isEmpty())item{EmptyState("Ready for offline listening","Save a permitted track from Search. Your audio stays inside this app and is removed if you uninstall it.")}
  items(sorted,key={it.songId}){d->songs.firstOrNull{it.id==d.songId}?.let{s->SongRow(s,s.favorite,{vm.play(s,queue)},{vm.favorite(s)},{add(s)},detail="${bytes(d.bytes)} · ~${d.kbps} kbps AAC · ${DateFormat.getDateInstance().format(Date(d.createdAt))}",extra={TextButton(onClick={deleting=d.songId}){Text("Delete")}})}}
 }
 deleting?.let{id->AlertDialog(onDismissRequest={deleting=null},title={Text("Delete downloaded audio?")},text={Text("Favorites and playlist entries will be kept.")},confirmButton={TextButton(onClick={vm.deleteDownload(id);deleting=null}){Text("Delete")}},dismissButton={TextButton(onClick={deleting=null}){Text("Cancel")}})}
}
