package com.svara.lite.player
import android.content.ComponentName
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.*
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.svara.lite.SvaraApp
import com.svara.lite.domain.model.Song
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlaybackState(val id:String="",val title:String="",val artist:String="",val artwork:String="",val playing:Boolean=false,val position:Long=0,val duration:Long=0,val shuffle:Boolean=false,val repeat:Int=0,val error:String="")
class PlayerConnection(private val app:SvaraApp,private val scope:CoroutineScope) {
 private val stateValue=MutableStateFlow(PlaybackState())
 val state=stateValue.asStateFlow()
 private var controller:MediaController?=null
 private val future=MediaController.Builder(app,SessionToken(app,ComponentName(app,PlaybackService::class.java))).buildAsync()
 private val listener=object:Player.Listener {
  override fun onEvents(player:Player,events:Player.Events)=sync()
  override fun onPlayerError(error:PlaybackException) { stateValue.value=stateValue.value.copy(error="Playback unavailable. Try another track or use a download.") }
 }
 private var ticker:Job?=null
 init {
  future.addListener({
   runCatching { future.get() }.onSuccess { c -> controller=c;c.addListener(listener);sync();ticker=scope.launch { while(isActive){sync();delay(500)} } }
    .onFailure { stateValue.value=stateValue.value.copy(error="Could not connect to the audio service.") }
  },ContextCompat.getMainExecutor(app))
 }
 private fun sync() {
  val c=controller?:return;val m=c.currentMediaItem?.mediaMetadata
  stateValue.value=PlaybackState(c.currentMediaItem?.mediaId?:"",m?.title?.toString()?:"",m?.artist?.toString()?:"",m?.artworkUri?.toString()?:"",c.isPlaying,c.currentPosition.coerceAtLeast(0),c.duration.coerceAtLeast(0),c.shuffleModeEnabled,c.repeatMode,if(c.playerError==null)"" else stateValue.value.error)
 }
 suspend fun play(songs:List<Song>,selected:Song) {
  val c=controller?:error("Player is connecting. Please try again.")
  val items=songs.map { s ->
   val uri=app.repository.playable(s)
   MediaItem.Builder().setMediaId(s.id).setUri(uri).setCustomCacheKey(s.id)
    .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setArtworkUri(s.artwork.takeIf{it.isNotBlank()}?.let(Uri::parse)).build()).build()
  }
  c.setMediaItems(items,songs.indexOfFirst{it.id==selected.id}.coerceAtLeast(0),0);c.prepare();c.play()
 }
 fun toggle(){controller?.run { if(isPlaying)pause() else play() }}
 fun previous(){controller?.seekToPreviousMediaItem()}
 fun next(){controller?.seekToNextMediaItem()}
 fun seek(ms:Long){controller?.seekTo(ms)}
 fun shuffle(){controller?.run { shuffleModeEnabled=!shuffleModeEnabled }}
 fun repeat(){controller?.run { repeatMode=when(repeatMode){Player.REPEAT_MODE_OFF->Player.REPEAT_MODE_ALL;Player.REPEAT_MODE_ALL->Player.REPEAT_MODE_ONE;else->Player.REPEAT_MODE_OFF} }}
 fun stop(){controller?.stop()}
 fun close(){ticker?.cancel();controller?.removeListener(listener);MediaController.releaseFuture(future)}
}
