package com.svara.lite.player
import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.*
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.svara.lite.SvaraApp
import com.svara.lite.MainActivity
class PlaybackService:MediaSessionService() {
 private var session:MediaSession?=null
 override fun onCreate() {
  super.onCreate()
  val app=application as SvaraApp
  val upstream=DefaultDataSource.Factory(this,OkHttpDataSource.Factory(app.http))
  val cached=DataSource.Factory {
   CacheDataSource.Factory().setCache(app.cache.store).setUpstreamDataSourceFactory(upstream).setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    .apply { if(app.settings.cacheMb==0)setCacheWriteDataSinkFactory(null) }.createDataSource()
  }
  val player=ExoPlayer.Builder(this).setMediaSourceFactory(DefaultMediaSourceFactory(cached))
   .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),true)
   .setHandleAudioBecomingNoisy(true).setWakeMode(C.WAKE_MODE_LOCAL).build()
  val intent=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
  session=MediaSession.Builder(this,player).setSessionActivity(intent).build()
 }
 override fun onGetSession(controllerInfo:MediaSession.ControllerInfo)=if(controllerInfo.packageName==packageName || controllerInfo.isTrusted)session else null
 override fun onDestroy() { session?.run { player.release();release() };session=null;super.onDestroy() }
}
