package com.svara.lite.downloads
import android.content.Context
import androidx.work.*
import com.svara.lite.SvaraApp
import com.svara.lite.data.database.Download
import com.svara.lite.domain.model.StoragePolicy
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Request
import java.io.File
import java.security.MessageDigest
object DownloadFiles {
 val mutex=Mutex()
 fun name(id:String)=MessageDigest.getInstance("SHA-256").digest(id.toByteArray()).joinToString(""){"%02x".format(it)}
 suspend fun delete(app:SvaraApp,id:String) { app.db.dao().download(id)?.let { val f=File(it.path);check(!f.exists()||f.delete()){ "Could not delete file" };app.db.dao().deleteDownload(id) } }
}
class DownloadWorker(context:Context,params:WorkerParameters):CoroutineWorker(context,params) {
 override suspend fun doWork():Result=withContext(Dispatchers.IO) { DownloadFiles.mutex.withLock {
  val app=applicationContext as SvaraApp
  val dao=app.db.dao()
  val id=inputData.getString("song")?:return@withLock Result.failure()
  val kbps=inputData.getInt("kbps",48)
  if(kbps !in StoragePolicy.bitrates)return@withLock Result.failure()
  val folder=File(app.filesDir,"downloads").apply{mkdirs()}
  val temp=File(folder,DownloadFiles.name(id)+".source.part")
  val output=File(folder,DownloadFiles.name(id)+".m4a.part")
  val target=File(folder,DownloadFiles.name(id)+".m4a")
  try {
   val existing=dao.download(id)
   if(existing!=null && File(existing.path).exists())return@withLock Result.success()
   // Refresh the provider permission immediately before every download.
   val song=app.repository.resolve(dao.song(id)?:error("Track missing"))
   check(song.downloadAllowed && song.downloadUrl?.startsWith("https://")==true) { "The artist does not allow this download" }
   check(song.duration>0){"Duration unavailable; cannot safely budget storage"}
   val estimate=StoragePolicy.estimate(song.duration,kbps)+100_000
   val limit=app.settings.limitMb*StoragePolicy.MB
   check(estimate<=limit) { "Song is larger than the download limit" }
   var records=dao.allDownloads()
   if(!StoragePolicy.fits(records.sumOf{it.bytes},estimate,limit) && app.settings.autoCleanup) {
    for(old in records) {
     if(StoragePolicy.fits(dao.allDownloads().sumOf{it.bytes},estimate,limit))break
     DownloadFiles.delete(app,old.songId)
    }
   }
   records=dao.allDownloads()
   check(StoragePolicy.fits(records.sumOf{it.bytes},estimate,limit)) { "Download limit reached. Delete songs or enable automatic cleanup." }
   temp.delete();output.delete()
   val cap=minOf(50*StoragePolicy.MB,folder.usableSpace-StoragePolicy.RESERVE-estimate)
   check(cap>0){"Not enough free storage for conversion"}
   setProgress(workDataOf("phase" to "Downloading source"))
   val call=app.http.newCall(Request.Builder().url(song.downloadUrl!!).build())
   call.execute().use { response ->
    check(response.isSuccessful) { "Source returned HTTP ${response.code}" }
    check(response.request.url.isHttps) { "Insecure source redirect refused" }
    val body=response.body?:error("Empty source")
    check(body.contentLength()<=cap) { "Source needs too much temporary space (maximum 50 MB)" }
    val type=body.contentType()?.toString().orEmpty()
    check(!type.contains("text/")&&!type.contains("json")&&!type.contains("mpegurl")) { "Source did not return a downloadable audio file" }
    body.byteStream().use { stream -> temp.outputStream().use { file ->
     val buffer=ByteArray(32*1024);var total=0L
     while(true) {
      currentCoroutineContext().ensureActive();val n=stream.read(buffer);if(n<0)break
      total+=n
      check(total<=cap && folder.usableSpace>StoragePolicy.RESERVE+estimate) { "Not enough temporary storage" }
      file.write(buffer,0,n)
     }
    } }
   }
   setProgress(workDataOf("phase" to "Converting to $kbps kbps AAC"))
   val context=currentCoroutineContext()
   val actual=AacEncoder.encode(temp,output,kbps,limit-records.sumOf{it.bytes}) { context.ensureActive();check(!isStopped){"Download stopped"} }
   check(output.length()>0 && output.length()+records.sumOf{it.bytes}<=limit) { "Converted file exceeds storage limit" }
   check(output.renameTo(target)) { "Could not save download" }
   dao.saveDownload(Download(id,target.absolutePath,target.length(),actual))
   Result.success()
  } catch(e:CancellationException) { throw e }
   catch(e:Exception) { Result.failure(workDataOf("error" to (e.message?:"Download failed"))) }
  finally { withContext(NonCancellable) { temp.delete();output.delete();if(dao.download(id)==null)target.delete() } }
 } }
 companion object {
  fun enqueue(app:SvaraApp,id:String,kbps:Int) {
   val request=OneTimeWorkRequestBuilder<DownloadWorker>().setInputData(workDataOf("song" to id,"kbps" to kbps))
    .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).setRequiresStorageNotLow(true).build())
    .addTag("music-download").addTag("song:$id").build()
   WorkManager.getInstance(app).enqueueUniqueWork("download:$id",ExistingWorkPolicy.KEEP,request)
  }
 }
}
