package com.svara.lite
import android.app.Application
import androidx.room.Room
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.svara.lite.data.api.*
import com.svara.lite.data.database.MusicDatabase
import com.svara.lite.data.repository.*
import com.svara.lite.player.StreamCache
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.withLock
import com.svara.lite.downloads.DownloadFiles
class SvaraApp:Application(),ImageLoaderFactory {
 override fun onCreate() {
  super.onCreate()
  CoroutineScope(SupervisorJob()+Dispatchers.IO).launch {
   runCatching { DownloadFiles.mutex.withLock {
    val keep=db.dao().allDownloads().map{it.path}.toSet()
    filesDir.resolve("downloads").listFiles()?.filter { it.absolutePath !in keep && System.currentTimeMillis()-it.lastModified()>86_400_000L }?.forEach { it.delete() }
   } }
  }
 }
 val settings by lazy { Settings(this) }
 val db by lazy { Room.databaseBuilder(this,MusicDatabase::class.java,"music.db").build() }
 val http by lazy { OkHttpClient.Builder().connectTimeout(15,TimeUnit.SECONDS).readTimeout(30,TimeUnit.SECONDS).callTimeout(90,TimeUnit.SECONDS).build() }
 val api by lazy { Retrofit.Builder().baseUrl("https://api.audius.co/").client(http).build().create(JsonApi::class.java) }
 val providers by lazy { listOf(AudiusProvider(api,settings),JamendoProvider(api,settings)) }
 val cache by lazy { StreamCache(this,settings) }
 val repository by lazy { MusicRepository(this) }
 override fun newImageLoader()=ImageLoader.Builder(this).okHttpClient(http)
  .memoryCache { MemoryCache.Builder(this).maxSizeBytes(4*1024*1024).build() }
  .diskCache { DiskCache.Builder().directory(cacheDir.resolve("artwork")).maxSizeBytes(2_000_000).build() }
  .crossfade(false).build()
}
