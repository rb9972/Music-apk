package com.svara.lite.ui.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.svara.lite.domain.model.Song
import com.svara.lite.ui.*

@Composable fun SearchScreen(vm:MusicViewModel,add:(Song)->Unit,download:(Song)->Unit){
 var query by rememberSaveable{mutableStateOf("")}
 val results by vm.results.collectAsStateWithLifecycle()
 val saved by vm.songs.collectAsStateWithLifecycle()
 val loading by vm.loading.collectAsStateWithLifecycle()
 val note by vm.searchNote.collectAsStateWithLifecycle()
 val online by vm.online.collectAsStateWithLifecycle()
 val recent by vm.recentSearches.collectAsStateWithLifecycle()
 val artists=results.distinctBy{it.artist.lowercase()}.take(8)

 fun runSearch(q:String=query,genre:Boolean=false){query=q;vm.search(q,genre)}

 LazyColumn(contentPadding=PaddingValues(bottom=28.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  item{Heading("Search","Songs, artists and mixes")}
  item{
   TextField(value=query,onValueChange={query=it},placeholder={Text("What do you want to listen to?")},singleLine=true,modifier=Modifier.fillMaxWidth(),leadingIcon={Text("⌕",fontSize=22.sp)},shape=androidx.compose.foundation.shape.RoundedCornerShape(12.dp),colors=TextFieldDefaults.colors(focusedContainerColor=Color.White,unfocusedContainerColor=Color.White,focusedTextColor=Color.Black,unfocusedTextColor=Color.Black,focusedPlaceholderColor=Color.DarkGray,unfocusedPlaceholderColor=Color.DarkGray,focusedIndicatorColor=Color.Transparent,unfocusedIndicatorColor=Color.Transparent),keyboardOptions=KeyboardOptions(imeAction=ImeAction.Search),keyboardActions=KeyboardActions(onSearch={runSearch()}))
  }
  if(query.isNotBlank())item{Button(onClick={runSearch()},enabled=online&&!loading,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=SvaraGreen,contentColor=Color.Black)){Text("Search",fontWeight=FontWeight.Bold)}}
  if(loading)item{LinearProgressIndicator(Modifier.fillMaxWidth(),color=SvaraGreen)}

  if(results.isEmpty()&&!loading){
   if(recent.isNotEmpty()){
    item{SectionHeader("Recent searches","Clear",vm::clearSearchHistory)}
    items(recent,key={"recent:$it"}){q->
     TextButton(onClick={runSearch(q)},modifier=Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth()){Text("◷",color=Muted);Spacer(Modifier.width(12.dp));Text(q,color=Color.White)}}
    }
   }
   item{SectionHeader("Browse all")}
   item{
    Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
     Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Box(Modifier.weight(1f)){GenreTile("Pop",listOf(Color(0xFF7C3AED),Color(0xFF2563EB))){runSearch("pop",true)}};Box(Modifier.weight(1f)){GenreTile("Chill",listOf(Color(0xFF0F766E),Color(0xFF115E59))){runSearch("chill",true)}}}
     Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Box(Modifier.weight(1f)){GenreTile("Electronic",listOf(Color(0xFFBE185D),Color(0xFF7E22CE))){runSearch("electronic",true)}};Box(Modifier.weight(1f)){GenreTile("Rock",listOf(Color(0xFFB45309),Color(0xFF991B1B))){runSearch("rock",true)}}}
     Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Box(Modifier.weight(1f)){GenreTile("Workout",listOf(Color(0xFFDC2626),Color(0xFFEA580C))){runSearch("workout",true)}};Box(Modifier.weight(1f)){GenreTile("Lo-fi",listOf(Color(0xFF334155),Color(0xFF4338CA))){runSearch("lofi",true)}}}
    }
   }
   item{Text("Free/legal catalogs may not contain every commercial release.",color=Muted,style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(top=8.dp))}
  } else if(results.isNotEmpty()){
   item{
    Text("Top result",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Color.White,modifier=Modifier.padding(top=8.dp))
    val top=results.first()
    Card(onClick={vm.play(top,results)},colors=CardDefaults.cardColors(containerColor=SvaraSurface),shape=androidx.compose.foundation.shape.RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth().padding(top=8.dp)){
     Row(Modifier.padding(14.dp),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
      Cover(top.artwork,Modifier.size(86.dp),12)
      Column(Modifier.weight(1f).padding(start=14.dp)){Text(top.title,maxLines=2,fontWeight=FontWeight.Bold,color=Color.White);Text(top.artist,color=Muted);Text("SONG • ${top.source}",color=Muted,style=MaterialTheme.typography.labelSmall,modifier=Modifier.padding(top=6.dp))}
      Surface(shape=androidx.compose.foundation.shape.CircleShape,color=SvaraGreen,modifier=Modifier.size(48.dp)){Box(contentAlignment=androidx.compose.ui.Alignment.Center){Text("▶",color=Color.Black)}}
     }
    }
   }
   if(artists.isNotEmpty()){
    item{SectionHeader("Artists")}
    item{LazyRow(horizontalArrangement=Arrangement.spacedBy(14.dp)){items(artists,key={"artist:${it.artist}"}){s->ArtistCard(s){runSearch(s.artist)}}}}
   }
   item{SectionHeader("Songs")}
   items(results,key={it.id}){s->SongListRow(s,saved.firstOrNull{it.id==s.id}?.favorite==true,{vm.play(s,results)},{vm.favorite(s)},{add(s)},if(s.downloadAllowed)({download(s)})else null,detail="${s.source} • ${time(s.duration)}")}
   if(note.isNotBlank())item{Text(note,color=Muted,style=MaterialTheme.typography.bodySmall)}
  }
 }
}
