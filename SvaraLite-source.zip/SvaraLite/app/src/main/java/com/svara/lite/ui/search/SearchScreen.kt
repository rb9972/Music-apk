package com.svara.lite.ui.search
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.svara.lite.domain.model.Song
import com.svara.lite.ui.*
@Composable fun SearchScreen(vm:MusicViewModel,add:(Song)->Unit,download:(Song)->Unit){
 var query by rememberSaveable{mutableStateOf("")};var genre by rememberSaveable{mutableStateOf(false)}
 val results by vm.results.collectAsStateWithLifecycle();val songs by vm.songs.collectAsStateWithLifecycle()
 val loading by vm.loading.collectAsStateWithLifecycle();val note by vm.searchNote.collectAsStateWithLifecycle()
 val online by vm.online.collectAsStateWithLifecycle()
 LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=24.dp)){
  item{Heading("Find your sound","Audius + Jamendo · independent music")}
  item{OutlinedTextField(value=query,onValueChange={query=it},label={Text(if(genre)"Genre" else "Song or artist")},singleLine=true,modifier=Modifier.fillMaxWidth(),keyboardOptions=KeyboardOptions(imeAction=ImeAction.Search),keyboardActions=KeyboardActions(onSearch={vm.search(query,genre)}))}
  item{Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){FilterChip(selected=genre,onClick={genre=!genre},label={Text("Genre search")});Button(onClick={vm.search(query,genre)},enabled=online&&!loading&&query.isNotBlank()){Text("Search")}}}
  if(loading)item{LinearProgressIndicator(Modifier.fillMaxWidth())}
  if(note.isNotBlank())item{Text(note,color=Muted)}
  if(results.isEmpty()&&!loading)item{EmptyState("Music with permission","These catalogs do not contain every commercial song. Add your free Jamendo client ID in Settings to enable Jamendo.")}
  items(results,key={it.id}){s->SongRow(s,songs.firstOrNull{it.id==s.id}?.favorite==true,{vm.play(s,results)},{vm.favorite(s)},{add(s)},if(s.downloadAllowed)({download(s)})else null,detail=if(s.downloadAllowed)"Offline download permitted" else "Streaming only")}
 }
}
