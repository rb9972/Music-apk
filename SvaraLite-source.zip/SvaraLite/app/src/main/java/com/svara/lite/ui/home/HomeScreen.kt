package com.svara.lite.ui.home
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.svara.lite.ui.*
import com.svara.lite.domain.model.Song
@Composable fun HomeScreen(vm:MusicViewModel,onSearch:()->Unit,add:(Song)->Unit,download:(Song)->Unit){
 val songs by vm.songs.collectAsStateWithLifecycle()
 val downloads by vm.downloads.collectAsStateWithLifecycle()
 val offline by vm.online.collectAsStateWithLifecycle()
 val recent=if(offline)songs.take(12) else songs.filter{s->s.source=="Device"||downloads.any{it.songId==s.id}}.take(12)
 LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=24.dp)){
  item{Heading("Less space. More music.","Your own little listening room.")}
  item{Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF343329))){Column(Modifier.padding(22.dp)){
   Text("A lighter kind of listening",style=MaterialTheme.typography.headlineSmall)
   Canvas(Modifier.fillMaxWidth().height(76.dp)){val heights=listOf(.2f,.45f,.7f,.4f,.95f,.6f,.3f,.8f,.5f,.2f,.65f,.35f);heights.forEachIndexed{i,h->val x=size.width/13*(i+1);drawLine(Amber,Offset(x,size.height*(1-h)/2),Offset(x,size.height*(1+h)/2),6.dp.toPx())}}
   Text("Discover independent artists. Keep only the songs you love.",color=Muted)
   Button(onClick=onSearch,modifier=Modifier.padding(top=12.dp)){Text("Find your next song")}
  }}}
  item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){Card(Modifier.weight(1f)){Column(Modifier.padding(16.dp)){Text("${downloads.size}",style=MaterialTheme.typography.headlineMedium,color=Amber);Text("Offline songs")}};Card(Modifier.weight(1f)){Column(Modifier.padding(16.dp)){Text("${vm.settings.limitMb} MB",style=MaterialTheme.typography.headlineMedium,color=Amber);Text("Download budget")}}}}
  item{Heading("Your collection","Favorites, discoveries and device music")}
  if(recent.isEmpty())item{EmptyState("Make this space yours","Search for independent music, or scan Device Music in Library.")}
  items(recent,key={it.id}){s->SongRow(s,s.favorite,{vm.play(s,recent)},{vm.favorite(s)},{add(s)},if(s.downloadAllowed)({download(s)})else null)}
 }
}
