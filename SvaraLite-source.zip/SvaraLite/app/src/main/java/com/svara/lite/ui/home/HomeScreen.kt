package com.svara.lite.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.svara.lite.domain.model.Song
import com.svara.lite.ui.*
import java.util.Calendar

@Composable fun HomeScreen(vm:MusicViewModel,onSearch:()->Unit,add:(Song)->Unit,download:(Song)->Unit){
 val saved by vm.songs.collectAsStateWithLifecycle()
 val discovery by vm.discovery.collectAsStateWithLifecycle()
 val recentIds by vm.recentPlayed.collectAsStateWithLifecycle()
 val online by vm.online.collectAsStateWithLifecycle()
 val all=(saved+discovery).distinctBy{it.id}
 val recent=recentIds.mapNotNull{id->all.firstOrNull{it.id==id}}.take(10)
 val trending=discovery.take(12)
 val madeForYou=(discovery.drop(6)+saved.filter{it.favorite}).distinctBy{it.id}.take(12)
 val artistPicks=all.distinctBy{it.artist.lowercase()}.take(10)
 val hour=Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
 val greeting=when(hour){in 5..11->"Good morning";in 12..16->"Good afternoon";else->"Good evening"}

 LaunchedEffect(online){if(online)vm.discover()}

 LazyColumn(contentPadding=PaddingValues(bottom=28.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
  item{
   Row(Modifier.fillMaxWidth().padding(top=8.dp,bottom=8.dp),horizontalArrangement=Arrangement.SpaceBetween){
    Text(greeting,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold,color=Color.White)
    Text("SVARA",color=SvaraGreen,fontWeight=FontWeight.ExtraBold)
   }
  }
  item{
   LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){
    items(listOf("All","Chill","Workout","Pop","Electronic")){g->
     AssistChip(onClick={if(g=="All")vm.discover() else {vm.search(g,true);onSearch()}},label={Text(g)},colors=AssistChipDefaults.assistChipColors(containerColor=SvaraSurface2,labelColor=Color.White),border=null)
    }
   }
  }

  if(recent.isNotEmpty()){
   item{SectionHeader("Recently played")}
   item{SongCardRow(recent){vm.play(it,recent)}}
  }

  item{SectionHeader("Trending now")}
  if(trending.isEmpty())item{EmptyState(if(online)"Loading your home feed…" else "You’re offline","Connect once to load fresh music suggestions. Your downloaded music still works offline.")}
  else item{SongCardRow(trending){vm.play(it,trending)}}

  if(madeForYou.isNotEmpty()){
   item{SectionHeader("Made for you")}
   item{SongCardRow(madeForYou){vm.play(it,madeForYou)}}
  }

  if(artistPicks.isNotEmpty()){
   item{SectionHeader("Artists & mixes")}
   item{
    LazyRow(horizontalArrangement=Arrangement.spacedBy(14.dp),contentPadding=PaddingValues(end=12.dp)){
     items(artistPicks,key={"artist:${it.artist}"}){s->ArtistCard(s){vm.search(s.artist,false);onSearch()}}
    }
   }
  }

  if(all.isNotEmpty()){
   item{SectionHeader("More to explore")}
   items(all.take(10),key={"more:${it.id}"}){s->
    SongListRow(s,saved.firstOrNull{it.id==s.id}?.favorite==true,{vm.play(s,all)},{vm.favorite(s)},{add(s)},if(s.downloadAllowed)({download(s)})else null,detail=if(s.downloadAllowed)"Download available" else "${s.source} • Stream")
   }
  }
 }
}
