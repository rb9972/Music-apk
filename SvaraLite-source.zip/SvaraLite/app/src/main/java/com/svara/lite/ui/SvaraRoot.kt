package com.svara.lite.ui
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.svara.lite.domain.model.*
import com.svara.lite.ui.home.HomeScreen
import com.svara.lite.ui.search.SearchScreen
import com.svara.lite.ui.library.LibraryScreen
import com.svara.lite.ui.downloads.DownloadsScreen
import com.svara.lite.ui.settings.SettingsScreen
@Composable fun SvaraRoot(vm:MusicViewModel) {
 val colors=darkColorScheme(primary=Amber,onPrimary=Color(0xFF33260E),background=Color(0xFF131619),surface=Color(0xFF1C2124),onSurface=Color(0xFFF1F1E8),secondary=Color(0xFFAED5C7))
 MaterialTheme(colorScheme=colors) {
  var tab by rememberSaveableTab()
  var settings by remember { mutableStateOf(false) }
  var fullPlayer by remember { mutableStateOf(false) }
  var adding by remember { mutableStateOf<Song?>(null) }
  var downloading by remember { mutableStateOf<Song?>(null) }
  val online by vm.online.collectAsStateWithLifecycle()
  val playback by vm.player.state.collectAsStateWithLifecycle()
  val notice by vm.notice.collectAsStateWithLifecycle()
  val playlists by vm.playlists.collectAsStateWithLifecycle()
  val update by vm.update.collectAsStateWithLifecycle()
  val context=LocalContext.current
  val snackbar=remember { SnackbarHostState() }
  LaunchedEffect(notice){if(notice.isNotBlank()){snackbar.showSnackbar(notice);vm.notice.value=""}}
  LaunchedEffect(tab){vm.refreshStorage()}
  Scaffold(snackbarHost={SnackbarHost(snackbar)},topBar={
   Column(Modifier.statusBarsPadding().padding(horizontal=20.dp)) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
     Text("SVARA",style=MaterialTheme.typography.titleLarge,color=Amber,modifier=Modifier.weight(1f))
     Text("LITE",style=MaterialTheme.typography.labelMedium,color=Muted)
     TextButton(onClick={settings=true;vm.refreshStorage()}){Text("Settings")}
    }
    if(!online)Text("You're Offline · Your saved music is ready",color=Amber,modifier=Modifier.padding(bottom=10.dp))
   }
  },bottomBar={
   Column {
    if(playback.id.isNotEmpty())Surface(color=Color(0xFF30342D),modifier=Modifier.fillMaxWidth().clickable{fullPlayer=true}) {
     Row(Modifier.padding(horizontal=16.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically){
      Cover(playback.artwork,Modifier.size(42.dp))
      Column(Modifier.weight(1f).padding(horizontal=12.dp)){Text(playback.title,maxLines=1);Text(playback.artist,maxLines=1,color=Muted,style=MaterialTheme.typography.labelMedium)}
      TextButton(onClick=vm.player::toggle){Text(if(playback.playing)"Pause" else "Play")}
      TextButton(onClick=vm.player::next){Text("Next")}
     }
    }
    NavigationBar {listOf("Home","Search","Library","Downloads").forEachIndexed { i,label -> NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(listOf("⌂","⌕","♫","↓")[i])},label={Text(label,maxLines=1)})}}
   }
  }){padding->
   Box(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp)){
    val add:(Song)->Unit={adding=it};val download:(Song)->Unit={downloading=it}
    when(tab){0->HomeScreen(vm,{tab=1},add,download);1->SearchScreen(vm,add,download);2->LibraryScreen(vm,add,download);3->DownloadsScreen(vm,add)}
   }
  }
  if(settings)FullSurface({settings=false}){SettingsScreen(vm)}
  if(fullPlayer)FullSurface({fullPlayer=false}){PlayerScreen(vm)}
  adding?.let { song -> AlertDialog(onDismissRequest={adding=null},title={Text("Add to playlist")},text={
   Column(Modifier.verticalScroll(rememberScrollState())){if(playlists.isEmpty())Text("Create a playlist in Library first.")
    playlists.forEach { p -> TextButton(onClick={vm.add(song,p.id);adding=null}){Text(p.name)} }
   }
  },confirmButton={TextButton(onClick={adding=null}){Text("Close")}}) }
  downloading?.let { song ->
   var quality by remember(song.id){mutableIntStateOf(vm.settings.bitrate)}
   AlertDialog(onDismissRequest={downloading=null},title={Text("Save offline")},text={Column(Modifier.verticalScroll(rememberScrollState())){
    Text(song.title,style=MaterialTheme.typography.titleMedium);Text(time(song.duration),color=Muted)
    StoragePolicy.bitrates.forEach { k -> Row(Modifier.fillMaxWidth().clickable { quality=k },verticalAlignment=Alignment.CenterVertically){RadioButton(selected=quality==k,onClick={quality=k});Text("$k kbps · ~${bytes(StoragePolicy.estimate(song.duration,k))}")} }
    Text("AAC conversion uses temporary space (up to 50 MB). Actual size and bitrate depend on your phone's encoder. The source's download permission is checked again.",style=MaterialTheme.typography.bodySmall,color=Muted)
    if(vm.settings.autoCleanup)Text("Auto cleanup is ON: older downloads may be deleted to make room.",color=Amber)
   }},confirmButton={Button(onClick={vm.download(song,quality);downloading=null}){Text("Download")}},dismissButton={TextButton(onClick={downloading=null}){Text("Cancel")}})
  }
  update?.let { u -> AlertDialog(onDismissRequest={vm.update.value=null},title={Text("New Update Available")},text={Text("Version ${u.version}")},confirmButton={Button(onClick={runCatching { context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u.url))) }.onFailure { vm.notice.value="No browser available" };vm.update.value=null}){Text("Download Update")}},dismissButton={TextButton(onClick={vm.update.value=null}){Text("Later")}}) }
 }
}
@Composable private fun rememberSaveableTab()=androidx.compose.runtime.saveable.rememberSaveable { mutableIntStateOf(0) }
@Composable fun FullSurface(close:()->Unit,content:@Composable ()->Unit) {
 Dialog(onDismissRequest=close,properties=DialogProperties(usePlatformDefaultWidth=false)){
  Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background){Column(Modifier.safeDrawingPadding().padding(horizontal=20.dp)){
   TextButton(onClick=close){Text("← Back")};Box(Modifier.weight(1f)){content()}
  }}
 }
}
