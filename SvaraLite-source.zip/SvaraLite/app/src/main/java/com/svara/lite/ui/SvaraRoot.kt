package com.svara.lite.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.svara.lite.domain.model.*
import com.svara.lite.ui.downloads.DownloadsScreen
import com.svara.lite.ui.home.HomeScreen
import com.svara.lite.ui.library.LibraryScreen
import com.svara.lite.ui.search.SearchScreen
import com.svara.lite.ui.settings.SettingsScreen

@Composable fun SvaraRoot(vm:MusicViewModel) {
 val colors=darkColorScheme(primary=SvaraGreen,onPrimary=Color.Black,background=SvaraBlack,surface=SvaraSurface,onSurface=Color.White,secondary=SvaraGreen,onBackground=Color.White)
 MaterialTheme(colorScheme=colors) {
  var tab by rememberSaveableTab()
  var settings by remember { mutableStateOf(false) }
  var fullPlayer by remember { mutableStateOf(false) }
  var adding by remember { mutableStateOf<Song?>(null) }
  var downloading by remember { mutableStateOf<Song?>(null) }
  var libraryDownloads by remember { mutableStateOf(false) }
  val online by vm.online.collectAsStateWithLifecycle()
  val playback by vm.player.state.collectAsStateWithLifecycle()
  val notice by vm.notice.collectAsStateWithLifecycle()
  val playlists by vm.playlists.collectAsStateWithLifecycle()
  val update by vm.update.collectAsStateWithLifecycle()
  val context=LocalContext.current
  val snackbar=remember { SnackbarHostState() }
  LaunchedEffect(notice){if(notice.isNotBlank()){snackbar.showSnackbar(notice);vm.notice.value=""}}
  LaunchedEffect(tab){vm.refreshStorage()}

  Scaffold(
   containerColor=SvaraBlack,
   snackbarHost={SnackbarHost(snackbar)},
   topBar={
    if(tab==0)Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=16.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
     Text("SVARA",fontWeight=FontWeight.ExtraBold,color=SvaraGreen,modifier=Modifier.weight(1f))
     if(!online)Text("Offline",color=Muted,style=MaterialTheme.typography.labelMedium,modifier=Modifier.padding(end=8.dp))
     TextButton(onClick={settings=true;vm.refreshStorage()}){Text("⚙",color=Color.White)}
    } else Spacer(Modifier.statusBarsPadding())
   },
   bottomBar={
    Column(Modifier.background(SvaraBlack)){
     if(playback.id.isNotEmpty())Surface(color=SvaraSurface2,shape=RoundedCornerShape(8.dp),modifier=Modifier.fillMaxWidth().padding(start=8.dp,end=8.dp,bottom=4.dp).clickable{fullPlayer=true}){
      Row(Modifier.padding(7.dp),verticalAlignment=Alignment.CenterVertically){
       Cover(playback.artwork,Modifier.size(44.dp),6)
       Column(Modifier.weight(1f).padding(horizontal=10.dp)){Text(playback.title,maxLines=1,fontWeight=FontWeight.SemiBold);Text(playback.artist,maxLines=1,color=Muted,style=MaterialTheme.typography.labelMedium)}
       TextButton(onClick=vm.player::toggle){Text(if(playback.playing)"Ⅱ" else "▶",color=Color.White)}
       TextButton(onClick=vm.player::next){Text("⏭",color=Color.White)}
      }
     }
     NavigationBar(containerColor=Color(0xFF0D0F10)){
      listOf("Home","Search","Library").forEachIndexed { i,label ->
       NavigationBarItem(selected=tab==i,onClick={tab=i;libraryDownloads=false},icon={Text(listOf("⌂","⌕","♫")[i])},label={Text(label)},colors=NavigationBarItemDefaults.colors(selectedIconColor=SvaraGreen,selectedTextColor=SvaraGreen,indicatorColor=Color.Transparent,unselectedIconColor=Muted,unselectedTextColor=Muted))
      }
     }
    }
   }
  ){padding->
   Box(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp)){
    val add:(Song)->Unit={adding=it};val download:(Song)->Unit={downloading=it}
    when(tab){
     0->HomeScreen(vm,{tab=1},add,download)
     1->SearchScreen(vm,add,download)
     2->if(libraryDownloads)DownloadsScreen(vm,add) else LibraryScreen(vm,add,download,onDownloads={libraryDownloads=true})
    }
   }
  }

  if(settings)FullSurface({settings=false}){SettingsScreen(vm)}
  if(fullPlayer)FullSurface({fullPlayer=false},showBack=false){PlayerScreen(vm,onClose={fullPlayer=false})}

  adding?.let { song -> AlertDialog(onDismissRequest={adding=null},title={Text("Add to playlist")},text={
   Column(Modifier.verticalScroll(rememberScrollState())){if(playlists.isEmpty())Text("Create a playlist in Library first.")
    playlists.forEach { p -> TextButton(onClick={vm.add(song,p.id);adding=null}){Text(p.name)} }
   }
  },confirmButton={TextButton(onClick={adding=null}){Text("Close")}}) }

  downloading?.let { song ->
   var quality by remember(song.id){mutableIntStateOf(vm.settings.bitrate)}
   AlertDialog(onDismissRequest={downloading=null},title={Text("Download for offline")},text={Column(Modifier.verticalScroll(rememberScrollState())){
    Text(song.title,style=MaterialTheme.typography.titleMedium);Text(time(song.duration),color=Muted)
    StoragePolicy.bitrates.forEach { k -> Row(Modifier.fillMaxWidth().clickable { quality=k },verticalAlignment=Alignment.CenterVertically){RadioButton(selected=quality==k,onClick={quality=k});Text("$k kbps · ~${bytes(StoragePolicy.estimate(song.duration,k))}")} }
    Text("Available only when the source permits downloading.",style=MaterialTheme.typography.bodySmall,color=Muted)
   }},confirmButton={Button(onClick={vm.download(song,quality);downloading=null}){Text("Download")}},dismissButton={TextButton(onClick={downloading=null}){Text("Cancel")}})
  }

  update?.let { u -> AlertDialog(onDismissRequest={vm.update.value=null},title={Text("New Update Available")},text={Text("Version ${u.version}")},confirmButton={Button(onClick={runCatching { context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(u.url))) }.onFailure { vm.notice.value="No browser available" };vm.update.value=null}){Text("Download Update")}},dismissButton={TextButton(onClick={vm.update.value=null}){Text("Later")}}) }
 }
}

@Composable private fun rememberSaveableTab()=androidx.compose.runtime.saveable.rememberSaveable { mutableIntStateOf(0) }

@Composable fun FullSurface(close:()->Unit,showBack:Boolean=true,content:@Composable ()->Unit) {
 Dialog(onDismissRequest=close,properties=DialogProperties(usePlatformDefaultWidth=false)){
  Surface(Modifier.fillMaxSize(),color=SvaraBlack){Column(Modifier.safeDrawingPadding().padding(horizontal=16.dp)){
   if(showBack)TextButton(onClick=close){Text("← Back",color=Color.White)}
   Box(Modifier.weight(1f)){content()}
  }}
 }
}
