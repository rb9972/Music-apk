package com.svara.lite.data.repository
import android.content.ContentUris
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.MediaStore
import com.svara.lite.SvaraApp
import com.svara.lite.domain.model.Song
import kotlinx.coroutines.*
import java.io.File
class MusicRepository(private val app:SvaraApp) {
 val dao=app.db.dao()
 fun online():Boolean {
  val cm=app.getSystemService(ConnectivityManager::class.java)
  return cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)==true
 }
 suspend fun search(query:String,genre:Boolean):Pair<List<Song>,List<String>> = coroutineScope {
  val results=app.providers.map { p -> async {
   try { p.search(query,genre) to "" } catch(e:CancellationException){throw e} catch(e:Exception){ emptyList<Song>() to "${p.name}: ${e.message ?: "unavailable"}" }
  } }.awaitAll()
  val merged=results.flatMap { it.first }.distinctBy { it.id }
  merged.forEach { dao.save(it) }
  merged to results.map { it.second }.filter { it.isNotBlank() }
 }
 suspend fun resolve(song:Song)=if(song.source=="Device")song else app.providers.first { it.name==song.source }.resolve(song).also { dao.save(it) }
 suspend fun playable(song:Song):String {
  val d=dao.download(song.id)
  if(d!=null && File(d.path).exists())return File(d.path).toURI().toString()
  return song.streamUrl
 }
 suspend fun deviceMusic():List<Song> = withContext(Dispatchers.IO) {
  val result=mutableListOf<Song>()
  val uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
  app.contentResolver.query(uri,arrayOf("_id","title","artist","duration"),"is_music != 0",null,"title ASC")?.use { c ->
   while(c.moveToNext()) {
    val id=c.getLong(0)
    result+=Song("Device:$id",c.getString(1)?:"Untitled",c.getString(2)?:"Unknown artist",duration=c.getLong(3)/1000,streamUrl=ContentUris.withAppendedId(uri,id).toString(),source="Device")
   }
  }
  result.forEach { dao.save(it) };result
 }
}
