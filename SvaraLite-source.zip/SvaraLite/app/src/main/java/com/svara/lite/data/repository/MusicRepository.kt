package com.svara.lite.data.repository
import android.content.ContentUris
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.MediaStore
import com.svara.lite.SvaraApp
import com.svara.lite.domain.model.Song
import kotlinx.coroutines.*
import java.io.File
import java.util.Locale

class MusicRepository(private val app:SvaraApp) {
 val dao=app.db.dao()
 fun online():Boolean {
  val cm=app.getSystemService(ConnectivityManager::class.java)
  return cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)==true
 }

 private fun normalized(s:String)=s.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9 ]")," ").replace(Regex("\\s+")," ").trim()
 private fun relevance(song:Song,query:String):Int {
  val q=normalized(query); if(q.isBlank()) return 0
  val title=normalized(song.title); val artist=normalized(song.artist)
  var score=0
  if(title==q) score+=120
  if(artist==q) score+=100
  if(title.startsWith(q)) score+=90 else if(title.contains(q)) score+=70
  if(artist.startsWith(q)) score+=75 else if(artist.contains(q)) score+=60
  val tokens=q.split(' ').filter{it.length>1}
  score += tokens.sumOf { t -> (if(title.split(' ').any{it==t}) 16 else if(title.contains(t)) 8 else 0) + (if(artist.split(' ').any{it==t}) 14 else if(artist.contains(t)) 7 else 0) }
  if(song.artwork.isNotBlank())score+=2
  return score
 }

 suspend fun search(query:String,genre:Boolean):Pair<List<Song>,List<String>> = coroutineScope {
  val results=app.providers.map { p -> async {
   try { p.search(query,genre) to "" } catch(e:CancellationException){throw e} catch(e:Exception){ emptyList<Song>() to "${p.name}: ${e.message ?: "unavailable"}" }
  } }.awaitAll()
  val merged=results.flatMap { it.first }.distinctBy { it.id }
  val ranked=if(genre) merged else merged.map{it to relevance(it,query)}.filter{it.second>=14}.sortedByDescending{it.second}.map{it.first}
  ranked to results.map { it.second }.filter { it.isNotBlank() }
 }

 suspend fun resolve(song:Song)=if(song.source=="Device")song else app.providers.first { it.name==song.source }.resolve(song).also { dao.save(it) }
 suspend fun playable(song:Song):String {
  val d=dao.download(song.id)
  if(d!=null && File(d.path).exists())return File(d.path).toURI().toString()
  return song.streamUrl
 }
 suspend fun deviceMusic():List<Song> = withContext(Dispatchers.IO) {
  val fields=arrayOf(MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.DURATION,MediaStore.Audio.Media.ALBUM_ID)
  val out=mutableListOf<Song>()
  app.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,fields,"${MediaStore.Audio.Media.IS_MUSIC} != 0",null,"${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { c ->
   val id=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);val title=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);val artist=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);val duration=c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);val album=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
   while(c.moveToNext()) {val mediaId=c.getLong(id);val uri=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,mediaId).toString();val albumId=c.getLong(album);val art=ContentUris.withAppendedId(android.net.Uri.parse("content://media/external/audio/albumart"),albumId).toString();out+=Song("Device:$mediaId",c.getString(title)?:"Unknown",c.getString(artist)?:"Unknown artist",art,(c.getLong(duration)/1000),uri,null,false,"Device")}
  };out
 }
}
