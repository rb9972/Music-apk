package com.svara.lite.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player

@Composable fun PlayerScreen(vm:MusicViewModel,onClose:()->Unit={}) {
 val p by vm.player.state.collectAsStateWithLifecycle()
 val autoplay by vm.autoplay.collectAsStateWithLifecycle()
 var seeking by remember {mutableStateOf<Float?>(null)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom=24.dp),horizontalAlignment=Alignment.CenterHorizontally){
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
   TextButton(onClick=onClose){Text("⌄",color=Color.White,fontSize=28.sp)}
   Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){Text("NOW PLAYING",style=MaterialTheme.typography.labelSmall,color=Muted);Text(p.artist,maxLines=1,color=Color.White,style=MaterialTheme.typography.labelMedium)}
   Text("⋮",color=Color.White,fontSize=24.sp,modifier=Modifier.padding(horizontal=14.dp))
  }
  Spacer(Modifier.height(18.dp))
  Cover(p.artwork,Modifier.fillMaxWidth(.88f).aspectRatio(1f),16)
  Spacer(Modifier.height(28.dp))
  Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
   Column(Modifier.weight(1f)){Text(p.title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,color=Color.White,maxLines=2);Text(p.artist,color=Muted,style=MaterialTheme.typography.titleMedium)}
   Text("♡",color=SvaraGreen,fontSize=30.sp)
  }
  if(p.error.isNotBlank())Text(p.error,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(top=8.dp))
  Spacer(Modifier.height(10.dp))
  Slider(value=seeking?:p.position.toFloat().coerceAtMost(p.duration.toFloat()),onValueChange={seeking=it},onValueChangeFinished={seeking?.let{vm.player.seek(it.toLong())};seeking=null},valueRange=0f..p.duration.coerceAtLeast(1).toFloat(),enabled=p.duration>0,colors=SliderDefaults.colors(thumbColor=Color.White,activeTrackColor=Color.White,inactiveTrackColor=Color.DarkGray))
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(time((seeking?.toLong()?:p.position)/1000),color=Muted,style=MaterialTheme.typography.labelSmall);Text(time(p.duration/1000),color=Muted,style=MaterialTheme.typography.labelSmall)}
  Spacer(Modifier.height(10.dp))
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){
   TextButton(onClick=vm.player::shuffle){Text("⤨",color=if(p.shuffle)SvaraGreen else Muted,fontSize=24.sp)}
   TextButton(onClick=vm.player::previous){Text("⏮",color=Color.White,fontSize=30.sp)}
   Surface(shape=CircleShape,color=Color.White,modifier=Modifier.size(70.dp).clickable(onClick=vm.player::toggle)){Box(contentAlignment=Alignment.Center){Text(if(p.playing)"Ⅱ" else "▶",color=Color.Black,fontSize=28.sp,fontWeight=FontWeight.Bold)}}
   TextButton(onClick=vm.player::next){Text("⏭",color=Color.White,fontSize=30.sp)}
   TextButton(onClick=vm.player::repeat){Text(if(p.repeat==Player.REPEAT_MODE_ONE)"↻1" else "↻",color=if(p.repeat!=Player.REPEAT_MODE_OFF)SvaraGreen else Muted,fontSize=24.sp)}
  }
  Spacer(Modifier.height(22.dp))
  Card(colors=CardDefaults.cardColors(containerColor=SvaraSurface),shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){
   Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){
    Column(Modifier.weight(1f)){Text("Autoplay",fontWeight=FontWeight.Bold,color=Color.White);Text("Continue with the rest of this music list",color=Muted,style=MaterialTheme.typography.bodySmall)}
    Switch(checked=autoplay,onCheckedChange={vm.toggleAutoplay()},colors=SwitchDefaults.colors(checkedThumbColor=Color.Black,checkedTrackColor=SvaraGreen))
   }
  }
  Spacer(Modifier.height(12.dp))
  Text("Background playback and lock-screen controls stay active while you listen.",color=Muted,style=MaterialTheme.typography.bodySmall)
 }
}
