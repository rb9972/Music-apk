package com.svara.lite.ui
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
@Composable fun PlayerScreen(vm:MusicViewModel) {
 val p by vm.player.state.collectAsStateWithLifecycle()
 var seeking by remember {mutableStateOf<Float?>(null)}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom=24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(20.dp)){
  Text("NOW PLAYING",color=Amber,style=MaterialTheme.typography.labelLarge)
  Cover(p.artwork,Modifier.fillMaxWidth(.85f).aspectRatio(1f))
  Text(p.title,style=MaterialTheme.typography.headlineMedium)
  Text(p.artist,color=Muted,style=MaterialTheme.typography.titleMedium)
  if(p.error.isNotBlank())Text(p.error,color=MaterialTheme.colorScheme.error)
  Column {
   Slider(value=seeking?:p.position.toFloat().coerceAtMost(p.duration.toFloat()),onValueChange={seeking=it},onValueChangeFinished={seeking?.let{vm.player.seek(it.toLong())};seeking=null},valueRange=0f..p.duration.coerceAtLeast(1).toFloat(),enabled=p.duration>0)
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(time((seeking?.toLong()?:p.position)/1000));Text(time(p.duration/1000))}
  }
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){OutlinedButton(onClick=vm.player::previous){Text("Previous")};Button(onClick=vm.player::toggle){Text(if(p.playing)"Pause" else "Play")};OutlinedButton(onClick=vm.player::next){Text("Next")}}
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){FilterChip(selected=p.shuffle,onClick=vm.player::shuffle,label={Text("Shuffle")});FilterChip(selected=p.repeat!=Player.REPEAT_MODE_OFF,onClick=vm.player::repeat,label={Text(when(p.repeat){Player.REPEAT_MODE_ALL->"Repeat all";Player.REPEAT_MODE_ONE->"Repeat one";else->"Repeat off"})})}
  Text("Music stays with you when the screen is locked.",color=Muted,style=MaterialTheme.typography.bodySmall)
 }
}
