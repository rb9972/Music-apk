package com.svara.lite.ui.library

import android.Manifest
import android.os.Build
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.svara.lite.ui.*
import com.svara.lite.domain.model.Song

@Composable fun LibraryScreen(vm:MusicViewModel,add:(Song)->Unit,download:(Song)->Unit,onDownloads:()->Unit){
 val songs by vm.songs.collectAsStateWithLifecycle();val local by vm.local.collectAsStateWithLifecycle()
 val playlists by vm.playlists.collectAsStateWithLifecycle();val links by vm.links.collectAsStateWithLifecycle()
 val recentIds by vm.recentPlayed.collectAsStateWithLifecycle()
 var section by remember{mutableStateOf("Liked")};var selected by remember{mutableStateOf<Long?>(null)}
 var naming by remember{mutableStateOf(false)};var rename by remember{mutableStateOf(false)};var name by remember{mutableStateOf("")};var deleting by remember{mutableStateOf(false)}
 val context=LocalContext.current
 val permission=if(Build.VERSION.SDK_INT>=33)Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
 val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){if(it)vm.scanDevice()else vm.notice.value="Audio access was denied."}
 val visible=when(section){"Device"->local;"Recent"->recentIds.mapNotNull{id->songs.firstOrNull{it.id==id}};"Playlists"->songs.filter{s->links.any{it.playlistId==selected&&it.songId==s.id}};else->songs.filter{it.favorite}}

 LazyColumn(contentPadding=PaddingValues(bottom=28.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  item{
   Row(Modifier.fillMaxWidth().padding(top=8.dp,bottom=10.dp),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
    Text("Your Library",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.ExtraBold,color=Color.White,modifier=Modifier.weight(1f))
    TextButton(onClick={name="";rename=false;naming=true}){Text("＋",color=Color.White)}
   }
  }
  item{
   Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){
    listOf("Liked","Playlists","Recent","Device").forEach{s->FilterChip(selected=section==s,onClick={section=s},label={Text(s)},colors=FilterChipDefaults.filterChipColors(selectedContainerColor=SvaraGreen,selectedLabelColor=Color.Black,containerColor=SvaraSurface2,labelColor=Color.White))}
   }
  }
  item{
   Card(onClick=onDownloads,colors=CardDefaults.cardColors(containerColor=Color.Transparent),modifier=Modifier.fillMaxWidth()){
    Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF115E59),Color(0xFF0F172A)))).padding(14.dp),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
     Surface(shape=androidx.compose.foundation.shape.RoundedCornerShape(8.dp),color=SvaraGreen,modifier=Modifier.size(54.dp)){Box(contentAlignment=androidx.compose.ui.Alignment.Center){Text("↓",color=Color.Black,fontWeight=FontWeight.Bold)}}
     Column(Modifier.padding(start=14.dp).weight(1f)){Text("Downloads",fontWeight=FontWeight.Bold,color=Color.White);Text("Offline music on this phone",color=Muted,style=MaterialTheme.typography.bodySmall)}
     Text("›",color=Color.White)
    }
   }
  }

  if(section=="Device")item{Button(onClick={if(ContextCompat.checkSelfPermission(context,permission)==PackageManager.PERMISSION_GRANTED)vm.scanDevice()else launcher.launch(permission)},colors=ButtonDefaults.buttonColors(containerColor=SvaraGreen,contentColor=Color.Black)){Text("Scan device music")}}

  if(section=="Playlists"){
   item{SectionHeader("Playlists")}
   items(playlists,key={"playlist:${it.id}"}){p->
    Card(onClick={selected=p.id},colors=CardDefaults.cardColors(containerColor=if(selected==p.id)SvaraSurface2 else SvaraSurface),shape=androidx.compose.foundation.shape.RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth()){
     Row(Modifier.padding(12.dp),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){
      Surface(shape=androidx.compose.foundation.shape.RoundedCornerShape(8.dp),color=Color(0xFF4C1D95),modifier=Modifier.size(54.dp)){Box(contentAlignment=androidx.compose.ui.Alignment.Center){Text("♫",color=Color.White)}}
      Column(Modifier.weight(1f).padding(start=12.dp)){Text(p.name,fontWeight=FontWeight.SemiBold,color=Color.White);Text("${links.count{it.playlistId==p.id}} songs",color=Muted,style=MaterialTheme.typography.bodySmall)}
     }
    }
   }
   if(selected!=null)item{Row{TextButton(onClick={name=playlists.firstOrNull{it.id==selected}?.name?:"";rename=true;naming=true}){Text("Rename")};TextButton(onClick={deleting=true}){Text("Delete")}}}
  }

  if(section!="Playlists"||selected!=null){
   item{SectionHeader(when(section){"Liked"->"Liked Songs";"Recent"->"Recently played";"Device"->"On this device";else->"Playlist songs"})}
   if(visible.isEmpty())item{EmptyState("Nothing here yet",when(section){"Device"->"Scan music stored on your phone.";"Recent"->"Play a song and it will appear here.";"Playlists"->"Choose a playlist or add songs to it.";else->"Tap the menu beside a song and add it to Liked Songs."})}
   items(visible,key={it.id}){s->SongListRow(s,songs.firstOrNull{it.id==s.id}?.favorite==true,{vm.play(s,visible)},{vm.favorite(s)},{add(s)},if(s.downloadAllowed)({download(s)})else null,extra={if(section=="Playlists"&&selected!=null)TextButton(onClick={vm.remove(s,selected!!)}){Text("Remove")}})}
  }
 }

 if(naming)AlertDialog(onDismissRequest={naming=false},title={Text(if(rename)"Rename playlist" else "Create playlist")},text={OutlinedTextField(value=name,onValueChange={name=it.take(80)},label={Text("Playlist name")},singleLine=true)},confirmButton={Button(enabled=name.isNotBlank(),onClick={if(rename)selected?.let{vm.renamePlaylist(it,name)}else vm.createPlaylist(name);naming=false}){Text("Save")}},dismissButton={TextButton(onClick={naming=false}){Text("Cancel")}})
 if(deleting)AlertDialog(onDismissRequest={deleting=false},title={Text("Delete this playlist?")},text={Text("Downloaded audio is kept. Only this playlist is removed.")},confirmButton={TextButton(onClick={selected?.let(vm::deletePlaylist);selected=null;deleting=false}){Text("Delete")}},dismissButton={TextButton(onClick={deleting=false}){Text("Cancel")}})
}
