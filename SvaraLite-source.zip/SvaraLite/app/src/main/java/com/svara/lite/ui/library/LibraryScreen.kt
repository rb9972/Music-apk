package com.svara.lite.ui.library
import android.Manifest
import android.os.Build
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.svara.lite.ui.*
import com.svara.lite.domain.model.Song
@Composable fun LibraryScreen(vm:MusicViewModel,add:(Song)->Unit,download:(Song)->Unit){
 val songs by vm.songs.collectAsStateWithLifecycle();val local by vm.local.collectAsStateWithLifecycle()
 val playlists by vm.playlists.collectAsStateWithLifecycle();val links by vm.links.collectAsStateWithLifecycle()
 val cached by vm.cached.collectAsStateWithLifecycle()
 var section by remember{mutableStateOf("Favorites")};var selected by remember{mutableStateOf<Long?>(null)}
 var naming by remember{mutableStateOf(false)};var rename by remember{mutableStateOf(false)};var name by remember{mutableStateOf("")};var deleting by remember{mutableStateOf(false)}
 val context=LocalContext.current
 val permission=if(Build.VERSION.SDK_INT>=33)Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
 val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){if(it)vm.scanDevice()else vm.notice.value="Audio access was denied. You can still stream and play app downloads."}
 val visible=when(section){"Device Music"->local;"Cached"->songs.filter{it.id in cached};"Playlists"->songs.filter{s->links.any{it.playlistId==selected&&it.songId==s.id}};else->songs.filter{it.favorite}}
 LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=24.dp)){
  item{Heading("Your library","Keep the music. Skip the clutter.")}
  item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Favorites","Playlists","Device Music","Cached").forEach{s->FilterChip(selected=section==s,onClick={section=s;vm.refreshStorage()},label={Text(s)})}}}
  if(section=="Device Music")item{Button(onClick={if(ContextCompat.checkSelfPermission(context,permission)==PackageManager.PERMISSION_GRANTED)vm.scanDevice()else launcher.launch(permission)}){Text("Scan device music")}}
  if(section=="Cached")item{Text("Only fully cached tracks are listed. Partial streams cannot play offline. Cache is temporary and may be evicted.",color=Muted)}
  if(section=="Playlists"){
   item{Button(onClick={name="";rename=false;naming=true}){Text("+ Create playlist")}}
   items(playlists,key={"playlist:${it.id}"}){p->OutlinedButton(onClick={selected=p.id},modifier=Modifier.fillMaxWidth()){Text((if(selected==p.id)"✓ " else "")+p.name+" · "+links.count{it.playlistId==p.id})}}
   if(selected!=null)item{Row{TextButton(onClick={name=playlists.firstOrNull{it.id==selected}?.name?:"";rename=true;naming=true}){Text("Rename")};TextButton(onClick={deleting=true}){Text("Delete playlist")}}}
  }
  if(visible.isEmpty())item{EmptyState("Nothing here yet",when(section){"Device Music"->"Scan audio stored on your phone. Files are played in place without copying.";"Playlists"->"Choose a playlist, then add songs with + Playlist.";"Cached"->"Complete a stream to make it eligible. A track larger than your cache cannot be kept whole.";else->"Tap Favorite on any song. Favorites do not download audio."})}
  items(visible,key={it.id}){s->SongRow(s,songs.firstOrNull{it.id==s.id}?.favorite==true,{vm.play(s,visible)},{vm.favorite(s)},{add(s)},if(s.downloadAllowed)({download(s)})else null,extra={if(section=="Playlists"&&selected!=null)TextButton(onClick={vm.remove(s,selected!!)}){Text("Remove")}})}
 }
 if(naming)AlertDialog(onDismissRequest={naming=false},title={Text(if(rename)"Rename playlist" else "Create playlist")},text={OutlinedTextField(value=name,onValueChange={name=it.take(80)},label={Text("Playlist name")},singleLine=true)},confirmButton={Button(enabled=name.isNotBlank(),onClick={if(rename)selected?.let{vm.renamePlaylist(it,name)}else vm.createPlaylist(name);naming=false}){Text("Save")}},dismissButton={TextButton(onClick={naming=false}){Text("Cancel")}})
 if(deleting)AlertDialog(onDismissRequest={deleting=false},title={Text("Delete this playlist?")},text={Text("Downloaded audio is kept. Only this playlist is removed.")},confirmButton={TextButton(onClick={selected?.let(vm::deletePlaylist);selected=null;deleting=false}){Text("Delete")}},dismissButton={TextButton(onClick={deleting=false}){Text("Cancel")}})
}
