package com.svara.lite.data.api
import com.svara.lite.domain.model.Song
interface MusicProvider {
 val name:String
 suspend fun search(query:String,genre:Boolean=false):List<Song>
 suspend fun resolve(song:Song):Song
}
