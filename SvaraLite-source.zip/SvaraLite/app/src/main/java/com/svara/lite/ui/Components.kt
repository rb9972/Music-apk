package com.svara.lite.ui
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import com.svara.lite.domain.model.Song
import java.util.Locale
val Amber=Color(0xFFF3BD64)
val Muted=Color(0xFFA3ABA9)
fun bytes(n:Long)=String.format(Locale.US,"%.1f MB",n/1_000_000.0)
fun time(seconds:Long)="${seconds/60}:${(seconds%60).toString().padStart(2,'0')}"
@Composable fun Heading(title:String,subtitle:String="") { Column(Modifier.padding(vertical=10.dp)){ Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold);if(subtitle.isNotBlank())Text(subtitle,color=Muted,style=MaterialTheme.typography.bodyMedium) } }
@Composable fun Cover(url:String,modifier:Modifier=Modifier) {
 Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF30342D)),contentAlignment=Alignment.Center) {
  Text("♪",color=Amber,fontSize=30.sp)
  if(url.isNotBlank())AsyncImage(model=url,contentDescription=null,contentScale=ContentScale.Crop,modifier=Modifier.fillMaxSize())
 }
}
@Composable fun SongRow(song:Song,favorite:Boolean,onPlay:()->Unit,onFavorite:()->Unit,onAdd:()->Unit,onDownload:(()->Unit)?=null,detail:String="",extra:@Composable RowScope.()->Unit={}) {
 val context=LocalContext.current
 Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFF202528)),shape=RoundedCornerShape(18.dp)) {
  Column(Modifier.padding(12.dp)) {
   Row(verticalAlignment=Alignment.CenterVertically) {
    Cover(song.artwork,Modifier.size(52.dp))
    Column(Modifier.weight(1f).padding(start=12.dp)) {
     Text(song.title,maxLines=2,overflow=TextOverflow.Ellipsis,fontWeight=FontWeight.SemiBold)
     Text(song.artist,color=Muted,maxLines=1,overflow=TextOverflow.Ellipsis)
     Text("${song.source} · ${time(song.duration)}",color=Amber,fontSize=12.sp)
    }
    FilledTonalButton(onClick=onPlay,contentPadding=PaddingValues(12.dp),modifier=Modifier.heightIn(min=48.dp)){Text("Play")}
   }
   if(detail.isNotBlank())Text(detail,color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=6.dp))
   Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),verticalAlignment=Alignment.CenterVertically) {
    TextButton(onClick=onFavorite){Text(if(favorite)"♥ Saved" else "♡ Favorite")}
    TextButton(onClick=onAdd){Text("+ Playlist")}
    if(onDownload!=null)TextButton(onClick=onDownload){Text("↓ Save")}
    if(song.pageUrl.startsWith("https://"))TextButton(onClick={runCatching{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(song.pageUrl)))}}){Text("Source ↗")}
    if(song.license.isNotBlank())TextButton(onClick={runCatching{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(song.license)))}}){Text("License ↗")}
    extra()
   }
  }
 }
}
@Composable fun EmptyState(title:String,description:String) {Column(Modifier.fillMaxWidth().padding(vertical=28.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(title,fontWeight=FontWeight.SemiBold,fontSize=20.sp);Text(description,color=Muted)} }
