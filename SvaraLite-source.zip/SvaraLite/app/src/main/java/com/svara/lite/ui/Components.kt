package com.svara.lite.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.svara.lite.domain.model.Song
import java.util.Locale

val SvaraGreen=Color(0xFF1ED760)
val SvaraBlack=Color(0xFF090B0C)
val SvaraSurface=Color(0xFF171A1D)
val SvaraSurface2=Color(0xFF22262A)
val Muted=Color(0xFF9AA0A6)
val Amber=SvaraGreen

fun bytes(n:Long)=String.format(Locale.US,"%.1f MB",n/1_000_000.0)
fun time(seconds:Long)="${seconds/60}:${(seconds%60).toString().padStart(2,'0')}"

@Composable fun Heading(title:String,subtitle:String="") {
 Column(Modifier.padding(top=8.dp,bottom=8.dp)) {
  Text(title,fontSize=27.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)
  if(subtitle.isNotBlank())Text(subtitle,color=Muted,style=MaterialTheme.typography.bodyMedium)
 }
}

@Composable fun SectionHeader(title:String,action:String="",onAction:(()->Unit)?=null){
 Row(Modifier.fillMaxWidth().padding(top=10.dp,bottom=8.dp),verticalAlignment=Alignment.CenterVertically){
  Text(title,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Color.White,modifier=Modifier.weight(1f))
  if(action.isNotBlank()&&onAction!=null)TextButton(onClick=onAction){Text(action,color=Muted)}
 }
}

@Composable fun Cover(url:String,modifier:Modifier=Modifier,radius:Int=10) {
 Box(modifier.clip(RoundedCornerShape(radius.dp)).background(SvaraSurface2),contentAlignment=Alignment.Center) {
  Text("♫",color=SvaraGreen,fontSize=28.sp,fontWeight=FontWeight.Bold)
  if(url.isNotBlank())AsyncImage(model=url,contentDescription=null,contentScale=ContentScale.Crop,modifier=Modifier.fillMaxSize())
 }
}

@Composable fun SongCard(song:Song,onPlay:()->Unit,modifier:Modifier=Modifier){
 Column(modifier.width(148.dp).clickable(onClick=onPlay)){
  Box{
   Cover(song.artwork,Modifier.fillMaxWidth().aspectRatio(1f),12)
   Surface(shape=CircleShape,color=SvaraGreen,modifier=Modifier.align(Alignment.BottomEnd).padding(8.dp).size(42.dp),shadowElevation=7.dp){
    Box(contentAlignment=Alignment.Center){Text("▶",color=Color.Black,fontSize=16.sp)}
   }
  }
  Text(song.title,maxLines=1,overflow=TextOverflow.Ellipsis,fontWeight=FontWeight.SemiBold,color=Color.White,modifier=Modifier.padding(top=8.dp))
  Text(song.artist,maxLines=1,overflow=TextOverflow.Ellipsis,color=Muted,fontSize=12.sp)
 }
}

@Composable fun SongCardRow(songs:List<Song>,onPlay:(Song)->Unit){
 LazyRow(horizontalArrangement=Arrangement.spacedBy(14.dp),contentPadding=PaddingValues(end=12.dp)){
  items(songs,key={it.id}){s->SongCard(s,{onPlay(s)})}
 }
}

@Composable fun ArtistCard(song:Song,onClick:()->Unit){
 Column(Modifier.width(126.dp).clickable(onClick=onClick),horizontalAlignment=Alignment.CenterHorizontally){
  Cover(song.artwork,Modifier.size(112.dp).clip(CircleShape),56)
  Text(song.artist,maxLines=1,overflow=TextOverflow.Ellipsis,fontWeight=FontWeight.SemiBold,color=Color.White,modifier=Modifier.padding(top=8.dp))
  Text("Artist",fontSize=12.sp,color=Muted)
 }
}

@Composable fun GenreTile(title:String,colors:List<Color>,onClick:()->Unit){
 Card(modifier=Modifier.height(82.dp).clickable(onClick=onClick),shape=RoundedCornerShape(12.dp),colors=CardDefaults.cardColors(containerColor=colors.first())){
  Box(Modifier.fillMaxSize().background(Brush.linearGradient(colors)).padding(14.dp)){
   Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp)
   Text("♫",color=Color.White.copy(alpha=.45f),fontSize=42.sp,modifier=Modifier.align(Alignment.BottomEnd))
  }
 }
}

@Composable fun SongListRow(
 song:Song,
 favorite:Boolean,
 onPlay:()->Unit,
 onFavorite:()->Unit,
 onAdd:()->Unit,
 onDownload:(()->Unit)?=null,
 detail:String="",
 extra:@Composable RowScope.()->Unit={}
){
 val context=LocalContext.current
 var menu by remember{mutableStateOf(false)}
 Row(Modifier.fillMaxWidth().clickable(onClick=onPlay).padding(vertical=7.dp),verticalAlignment=Alignment.CenterVertically){
  Cover(song.artwork,Modifier.size(56.dp),7)
  Column(Modifier.weight(1f).padding(horizontal=12.dp)){
   Text(song.title,maxLines=1,overflow=TextOverflow.Ellipsis,fontWeight=FontWeight.SemiBold,color=Color.White)
   Text(song.artist,maxLines=1,overflow=TextOverflow.Ellipsis,color=Muted,fontSize=13.sp)
   if(detail.isNotBlank())Text(detail,maxLines=1,overflow=TextOverflow.Ellipsis,color=SvaraGreen,fontSize=11.sp)
  }
  Box{
   TextButton(onClick={menu=true},contentPadding=PaddingValues(horizontal=10.dp)){Text("⋮",color=Color.White,fontSize=22.sp)}
   DropdownMenu(expanded=menu,onDismissRequest={menu=false},containerColor=SvaraSurface2){
    DropdownMenuItem(text={Text(if(favorite)"Remove from Liked Songs" else "Add to Liked Songs")},onClick={menu=false;onFavorite()})
    DropdownMenuItem(text={Text("Add to playlist")},onClick={menu=false;onAdd()})
    if(onDownload!=null)DropdownMenuItem(text={Text("Download for offline")},onClick={menu=false;onDownload()})
    if(song.pageUrl.startsWith("https://"))DropdownMenuItem(text={Text("Open source page")},onClick={menu=false;runCatching{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(song.pageUrl)))}})
   }
  }
  extra()
 }
}

@Composable fun SongRow(song:Song,favorite:Boolean,onPlay:()->Unit,onFavorite:()->Unit,onAdd:()->Unit,onDownload:(()->Unit)?=null,detail:String="",extra:@Composable RowScope.()->Unit={})=
 SongListRow(song,favorite,onPlay,onFavorite,onAdd,onDownload,detail,extra)

@Composable fun EmptyState(title:String,description:String) {
 Column(Modifier.fillMaxWidth().padding(vertical=28.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp,color=Color.White)
  Text(description,color=Muted)
 }
}
