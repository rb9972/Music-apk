package com.svara.lite.data.repository
import android.content.Context

class Settings(context:Context) {
 private val p=context.getSharedPreferences("settings",Context.MODE_PRIVATE)
 var limitMb:Int get()=p.getInt("limit",50); set(v){p.edit().putInt("limit",v.coerceIn(1,1000)).apply()}
 var cacheMb:Int get()=p.getInt("cache",10); set(v){p.edit().putInt("cache",v.coerceIn(0,30)).apply()}
 var bitrate:Int get()=p.getInt("bitrate",48); set(v){p.edit().putInt("bitrate",v).apply()}
 var autoCleanup:Boolean get()=p.getBoolean("cleanup",false); set(v){p.edit().putBoolean("cleanup",v).apply()}
 var autoplay:Boolean get()=p.getBoolean("autoplay",true); set(v){p.edit().putBoolean("autoplay",v).apply()}
 var jamendoId:String get()=p.getString("jamendo","")!!; set(v){p.edit().putString("jamendo",v.trim()).apply()}
 var audiusKey:String get()=p.getString("audius","")!!; set(v){p.edit().putString("audius",v.trim()).apply()}
 var recentSearches:List<String>
  get()=p.getString("recent_searches","")!!.split("\u001F").filter{it.isNotBlank()}.take(8)
  set(v){p.edit().putString("recent_searches",v.filter{it.isNotBlank()}.distinct().take(8).joinToString("\u001F")).apply()}
 var recentSongIds:List<String>
  get()=p.getString("recent_song_ids","")!!.split("\u001F").filter{it.isNotBlank()}.take(20)
  set(v){p.edit().putString("recent_song_ids",v.filter{it.isNotBlank()}.distinct().take(20).joinToString("\u001F")).apply()}
}
