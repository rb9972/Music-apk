package com.svara.lite.ui
import android.app.Application
import android.net.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkManager
import coil.imageLoader
import com.svara.lite.*
import com.svara.lite.data.database.*
import com.svara.lite.domain.model.Song
import com.svara.lite.downloads.*
import com.svara.lite.player.PlayerConnection
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.withLock
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import java.io.File

data class StorageStats(val free:Long=0,val app:Long=0,val downloads:Long=0,val cache:Long=0,val temporary:Long=0)
data class AppUpdate(val version:String,val url:String)
class MusicViewModel(application:Application):AndroidViewModel(application) {
 val app=application as SvaraApp
 val settings=app.settings
 private val dao=app.db.dao()
 val songs=dao.songs().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 val downloads=dao.downloads().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 val playlists=dao.playlists().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 val links=dao.links().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 val work=WorkManager.getInstance(app).getWorkInfosByTagFlow("music-download").stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 val player=PlayerConnection(app,viewModelScope)
 val results=MutableStateFlow<List<Song>>(emptyList())
 val discovery=MutableStateFlow<List<Song>>(emptyList())
 val recentSearches=MutableStateFlow(settings.recentSearches)
 val recentPlayed=MutableStateFlow(settings.recentSongIds)
 val autoplay=MutableStateFlow(settings.autoplay)
 val local=MutableStateFlow<List<Song>>(emptyList())
 val loading=MutableStateFlow(false)
 val notice=MutableStateFlow("")
 val searchNote=MutableStateFlow("")
 val online=MutableStateFlow(app.repository.online())
 val storage=MutableStateFlow(StorageStats())
 val cached=MutableStateFlow<Set<String>>(emptySet())
 val update=MutableStateFlow<AppUpdate?>(null)
 private var searchJob:Job?=null
 private val cm=app.getSystemService(ConnectivityManager::class.java)
 private val network=object:ConnectivityManager.NetworkCallback(){
  override fun onAvailable(network:Network){online.value=app.repository.online()}
  override fun onLost(network:Network){online.value=app.repository.online()}
  override fun onCapabilitiesChanged(network:Network,n:NetworkCapabilities){online.value=app.repository.online()}
 }
 init { cm.registerDefaultNetworkCallback(network);refreshStorage();discover();if(BuildConfig.UPDATE_URL.isNotBlank())checkUpdate(false) }
 fun task(block:suspend ()->Unit) {viewModelScope.launch {try{block()}catch(e:CancellationException){throw e}catch(e:Exception){notice.value=e.message?:"Please try again"}}}
 fun search(query:String,genre:Boolean) {
  searchJob?.cancel()
  if(!online.value){searchNote.value="You're offline. Open Library or Downloads.";return}
  val clean=query.trim();if(clean.isBlank())return
  val recent=(listOf(clean)+recentSearches.value.filterNot{it.equals(clean,true)}).take(8)
  settings.recentSearches=recent;recentSearches.value=recent
  searchJob=viewModelScope.launch {
   loading.value=true;searchNote.value=""
   try{val (found,errors)=app.repository.search(clean,genre);results.value=found;searchNote.value=errors.joinToString("\n").ifBlank { if(found.isEmpty())"No close match found in the available free music catalogs." else "${found.size} relevant results" }}
   catch(e:CancellationException){throw e}
   finally{loading.value=false}
  }
 }
 fun clearSearchHistory(){settings.recentSearches=emptyList();recentSearches.value=emptyList()}
 fun discover()=task {
  if(!online.value||discovery.value.isNotEmpty())return@task
  val queries=listOf("chill","electronic","pop","rock")
  val found=withContext(Dispatchers.IO){queries.flatMap { q -> runCatching{app.repository.search(q,true).first.take(8)}.getOrDefault(emptyList()) }}
  discovery.value=found.distinctBy{it.id}.take(28)
 }
 fun toggleAutoplay(){val v=!autoplay.value;autoplay.value=v;settings.autoplay=v}
 fun play(song:Song,queue:List<Song>)=task {
  val allowed=if(online.value)queue else queue.filter { it.source=="Device"||downloads.value.any{d->d.songId==it.id}||app.cache.complete(it) }
  check(allowed.any{it.id==song.id}){"This song is not available offline"}
  dao.save(song)
  val ids=(listOf(song.id)+recentPlayed.value.filterNot{it==song.id}).take(20);recentPlayed.value=ids;settings.recentSongIds=ids
  // Refresh expiring stream URLs for the selected track, without blocking local/offline playback.
  val refreshed=if(online.value && song.source!="Device" && downloads.value.none{it.songId==song.id} && !app.cache.complete(song))app.repository.resolve(song) else song
  val actualQueue=if(autoplay.value) allowed else listOf(song)
  player.play(actualQueue.map{if(it.id==song.id)refreshed else it},refreshed)
 }
 fun favorite(song:Song)=task {dao.save(song);dao.favorite(song.id)}
 fun createPlaylist(name:String)=task {check(name.trim().isNotEmpty());dao.createPlaylist(Playlist(name=name.trim().take(80)))}
 fun renamePlaylist(id:Long,name:String)=task {check(name.trim().isNotEmpty());dao.renamePlaylist(id,name.trim().take(80))}
 fun deletePlaylist(id:Long)=task{dao.deletePlaylist(id)}
 fun add(song:Song,id:Long)=task{dao.save(song);dao.addToPlaylist(PlaylistSong(id,song.id));notice.value="Added to playlist"}
 fun remove(song:Song,id:Long)=task{dao.removeFromPlaylist(id,song.id)}
 fun scanDevice()=task {local.value=app.repository.deviceMusic();notice.value="${local.value.size} device songs found"}
 fun download(song:Song,kbps:Int)=task {dao.save(song);DownloadWorker.enqueue(app,song.id,kbps);notice.value="Queued. Track progress in Downloads."}
 fun deleteDownload(id:String)=task { if(player.state.value.id==id)player.stop();withContext(Dispatchers.IO){DownloadFiles.mutex.withLock{DownloadFiles.delete(app,id)}};refreshStorage() }
 fun deleteAll()=task {
  withContext(Dispatchers.IO) { WorkManager.getInstance(app).cancelAllWorkByTag("music-download").result.get() }
  player.stop()
  withContext(Dispatchers.IO){DownloadFiles.mutex.withLock{dao.allDownloads().forEach{DownloadFiles.delete(app,it.songId)}}};refreshStorage()
 }
 fun clearCache()=task {withContext(Dispatchers.IO){app.cache.clear();app.imageLoader.diskCache?.clear()};app.imageLoader.memoryCache?.clear();refreshStorage()}
 fun setCache(mb:Int){settings.cacheMb=mb;task{withContext(Dispatchers.IO){app.cache.resize()};refreshStorage()}}
 fun refreshStorage()=task { withContext(Dispatchers.IO) {
  fun size(f:File)=if(f.exists())f.walkTopDown().filter{it.isFile}.sumOf{it.length()} else 0L
  val apk=listOfNotNull(app.applicationInfo.sourceDir).plus(app.applicationInfo.splitSourceDirs?.toList()?:emptyList()).sumOf{File(it).length()}
  val data=size(app.filesDir)+size(app.cacheDir)+size(File(app.applicationInfo.dataDir,"databases"))+size(File(app.applicationInfo.dataDir,"shared_prefs"))
  val temp=File(app.filesDir,"downloads").listFiles()?.filter{it.name.endsWith(".part")}?.sumOf{it.length()}?:0
  storage.value=StorageStats(app.filesDir.usableSpace,apk+data,dao.allDownloads().sumOf{it.bytes},size(app.cacheDir),temp)
  cached.value=songs.value.filter{app.cache.complete(it)}.map{it.id}.toSet()
 } }
 fun checkUpdate(manual:Boolean=true)=task {
  val url=BuildConfig.UPDATE_URL.toHttpUrlOrNull()
  if(url==null||!url.isHttps){if(manual)notice.value="Update server is not configured in this build.";return@task}
  withContext(Dispatchers.IO) {
   val request=okhttp3.Request.Builder().url(url).build()
   app.http.newCall(request).execute().use { r ->
    check(r.isSuccessful){"Update check unavailable"}
    val body=r.body?:error("Empty update response")
    val raw=body.byteStream().use { input ->
     val out=java.io.ByteArrayOutputStream();val buf=ByteArray(4096)
     while(out.size()<=65536){val n=input.read(buf,0,minOf(buf.size,65537-out.size()));if(n<0)break;out.write(buf,0,n)}
     out.toByteArray()
    }
    check(raw.size<=65536){"Invalid update metadata"}
    val json=JSONObject(raw.toString(Charsets.UTF_8))
    if(json.getInt("versionCode")>BuildConfig.VERSION_CODE){
     val apk=json.getString("apkUrl").toHttpUrlOrNull()?:error("Invalid APK URL")
     check(apk.isHttps && apk.host==url.host && apk.encodedPath.endsWith(".apk")){"Update must use the configured HTTPS host"}
     update.value=AppUpdate(json.getString("versionName"),apk.toString())
    } else if(manual)notice.value="You have the latest version."
   }
  }
 }
 override fun onCleared(){cm.unregisterNetworkCallback(network);player.close();super.onCleared()}
}
