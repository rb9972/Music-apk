package com.svara.lite
import com.svara.lite.domain.model.StoragePolicy
import org.junit.Assert.*
import org.junit.Test
class StoragePolicyTest {
 @Test fun estimatesIncludeContainerAllowance() {
  assertEquals(1_297_800L,StoragePolicy.estimate(210,48))
  assertEquals(865_200L,StoragePolicy.estimate(210,32))
 }
 @Test fun storageLimitRejectsOversizeAndNegativeRequests() {
  assertTrue(StoragePolicy.fits(24_000_000,1_000_000,25_000_000))
  assertFalse(StoragePolicy.fits(24_000_000,1_000_001,25_000_000))
  assertFalse(StoragePolicy.fits(0,-1,25_000_000))
  assertFalse(StoragePolicy.fits(26_000_000,1,25_000_000))
 }
}
