#!/usr/bin/env python3
"""Package only a real built APK. Read version metadata from aapt, never guess."""
import argparse, hashlib, json, pathlib, re, shutil, subprocess
from urllib.parse import urlparse
p=argparse.ArgumentParser()
p.add_argument('--apk',required=True);p.add_argument('--base-url',required=True);p.add_argument('--aapt',required=True)
a=p.parse_args();apk=pathlib.Path(a.apk);base=a.base_url.rstrip('/')
if not apk.is_file(): p.error('APK does not exist. Build it first.')
if urlparse(base).scheme!='https': p.error('A public HTTPS base URL is required.')
meta=subprocess.check_output([a.aapt,'dump','badging',str(apk)],text=True)
m=re.search(r"package: name='com.svara.lite' versionCode='(\d+)' versionName='([^']+)'",meta)
if not m: p.error('Expected a com.svara.lite release APK, not debug or another package.')
d=pathlib.Path(__file__).resolve().parents[1]/'distribution';d.mkdir(exist_ok=True)
filename='music-app-release.apk';shutil.copyfile(apk,d/filename)
info=dict(versionCode=int(m[1]),versionName=m[2],apkUrl=f'{base}/{filename}',sizeBytes=apk.stat().st_size,sha256=hashlib.sha256(apk.read_bytes()).hexdigest())
(d/'version.json').write_text(json.dumps(info,indent=2)+'\n')
(d/'SHA256SUMS').write_text(info['sha256']+'  '+filename+'\n')
(d/'RELEASE-NOTES.md').write_text(f"Svara Lite {m[2]}\n\nNative Android music player.\n\nAPK: {info['sizeBytes']/1_000_000:.2f} MB\n\nAndroid 8.0+. Install manually after downloading; updates require the same signing key.\n")
print(f'Packaged {filename}: {info["sizeBytes"]/1_000_000:.2f} MB')
