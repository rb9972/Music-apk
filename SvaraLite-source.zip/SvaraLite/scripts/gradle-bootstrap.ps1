$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
$root = Join-Path $env:USERPROFILE '.gradle\svara-bootstrap'
$dist = Join-Path $root 'gradle-8.13'
$bin = Join-Path $dist 'bin\gradle.bat'
if (!(Test-Path $bin)) {
 New-Item -ItemType Directory -Force -Path $root | Out-Null
 $zip = Join-Path $root 'gradle-8.13-bin.zip'
 $url = 'https://services.gradle.org/distributions/gradle-8.13-bin.zip'
 Invoke-WebRequest $url -OutFile $zip
 $expected = (Invoke-RestMethod "$url.sha256").Trim()
 if ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -ne $expected.ToLower()) { throw 'Gradle checksum mismatch' }
 Expand-Archive -Force $zip $root
 Remove-Item $zip
}
& $bin @args
exit $LASTEXITCODE
