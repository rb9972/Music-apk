# Svara Lite — native Android music player

**Delivery status: source project, not a verified APK.** This project was created in an environment with Java 17 but no Android SDK or Gradle installation. The actual `./gradlew assembleDebug` attempt stopped while downloading Gradle: `curl: (28) Proxy CONNECT aborted due to timeout`. Google SDK downloads also timed out. No debug APK, release APK, emulator run, or measured APK size is included. The code requires a successful Android build and the device checks below before being described as working.

This is a Kotlin / Jetpack Compose Android application, not a website wrapped in an APK. `distribution/index.html` is only an optional APK download page.

## What is implemented in source

- Android 8+ (min SDK 26), compile/target SDK 36, JVM 17.
- Original charcoal/amber UI: Home, Search, Library, Downloads; mini player and full player.
- Audius and Jamendo adapters behind `MusicProvider`, merged search with explicit genre mode and separate provider error messages.
- Media3 ExoPlayer, `MediaSessionService`, foreground playback notification, lock-screen controls, audio focus and headphone-disconnect handling.
- Play/pause, previous/next, seek, shuffle and repeat off/all/one.
- Room songs, favorites, playlists and membership tables; create/rename/delete/add/remove operations. Favorites do not download files.
- WorkManager downloads, unique work per song, serialized storage mutations, source permission revalidation, cancelled/failed partial-file cleanup and old orphan cleanup.
- Real AAC conversion with Android MediaCodec/MediaMuxer at requested 32/48/64/96 kbps, default 48. Hardware encoding avoids an FFmpeg bundle. Actual bitrate is measured and shown.
- Download budgets 25/50/75/100 MB or 1–1000 MB custom, default 50 MB. Estimated size before download, actual size after download, size/newest/oldest sort, deletion controls.
- Automatic deletion is OFF by default. Turning it on requires explicit confirmation and permits oldest-first deletion, including favorited downloads. Playlist/favorite metadata remains.
- Streaming cache default 10 MB, configurable off/10/20/30 MB; mutable LRU eviction. Coil artwork cache capped at 2 MB on disk and 4 MiB in memory.
- Fully cached tracks listed separately from partial streams. Offline queue filters to downloads, complete cache entries and device files.
- MediaStore device audio scan with only the applicable Android audio/storage permission; device files are played in place without duplication.
- Connectivity banner, persisted offline library, manual update prompt from configured HTTPS metadata. No silent installation.
- Release signing configuration, debug/release GitHub Actions build, APK packaging script, checksums and optional static download page.

These are implementation descriptions, not claims that device tests have passed.

## Online catalogs and credentials

This app does not supply Spotify, YouTube, or a complete mainstream music catalog. Provider outages, rate limits and content removals can affect results.

1. Audius public discovery is configured at `https://api.audius.co/v1`. If its API requires your app key, add a free public API key in Settings. Never enter an API secret.
2. Register your app for a free Jamendo client ID at <https://devportal.jamendo.com/>. Enter the ID in Settings. Jamendo is disabled until configured; no shared or fabricated credential is shipped.
3. Search by song/artist, or enable Genre search. Each result identifies the source and provides source/license links where available.

Jamendo downloads require BOTH `audiodownload_allowed=true` and a nonempty HTTPS `audiodownload` URL. The adapter requests `mp31` (96 kbps) for both stream and download; smaller files are created by real on-device conversion, not a made-up API bitrate parameter.

Audius downloads fail closed: the adapter requires explicit downloadable metadata, no required follow, an explicitly ungated download and no download conditions. Missing/conditional permission metadata makes a song streaming-only. Gated/unlisted/deleted tracks are excluded. The current Audius adapter still needs a live API smoke test; download metadata may vary between API versions.

Both providers recheck the selected song before a new download. The worker never substitutes a streaming URL for a missing download URL. No DRM, premium bypass, account impersonation, protected stream extraction, or secret key is included.

References checked during implementation:
- <https://developer.jamendo.com/v3.0/tracks>
- <https://docs.audius.co/api/>
- <https://developer.android.com/media/media3/session/background-playback>
- <https://developer.android.com/build/releases/agp-8-13-0-release-notes>

## Storage with only 200 MB free

Offline audio always uses storage. An APK download and installation also need temporary space; Android may require more than the final APK size. The desired 15–30 MB APK target cannot be confirmed before a release build.

Suggested starting settings: **25 MB downloads, 10 MB cache, 48 kbps AAC**. Default download budget in code is 50 MB.

A 3:30 song uses approximately:

| Requested bitrate | Raw audio size | App estimate including 3% allowance |
|---|---:|---:|
| 32 kbps | 0.84 MB | 0.87 MB |
| 48 kbps | 1.26 MB | 1.30 MB |
| 64 kbps | 1.68 MB | 1.73 MB |
| 96 kbps | 2.52 MB | 2.60 MB |

Downloads first fetch an allowed original file, then convert it. The original is temporary (maximum 50 MB), removed after completion/failure/cancellation, and never duplicated per playlist. A 20 MB phone-space reserve is enforced, with checks while downloading and encoding. Oversized originals are rejected rather than filling the phone. The source and converted file briefly coexist; a 48 kbps final file does not mean only that much space is needed during conversion.

The encoder may vary the requested bitrate. Unsupported codecs, multichannel audio, malformed/protected audio and conversion stalls fail with a message. No full-quality fallback is silently saved.

Cache Off disables new cache sinks when the next media source opens; an already active stream can finish its current write. The streaming-cache budget applies to committed audio spans; active write fragments, index metadata, artwork and database files add some overhead. Clearing cache while streaming can be followed by fresh cache writes. Lowering the download budget does not immediately delete saved audio; it blocks new downloads until space is made or authorized cleanup runs.

“App storage” includes APK bytes and accessible app files, not every Android-managed optimized-code allocation. Android Settings is authoritative for installed disk use. Streaming can consume mobile data independently of disk-cache limits.

## Fastest build route: GitHub Actions

No Android Studio installation on the phone is needed.

1. Unzip this project on your computer and put its **contents** at the root of a GitHub repository, including `.github/workflows/android.yml`.
2. Open the repository's **Actions → Build Android APK → Run workflow**.
3. Leave `release` and `publish` off for the first debug build. The workflow runs unit tests, lint and `assembleDebug`.
4. A successful run produces the `Svara-Lite-debug-APK` artifact. Download/extract its ZIP and install `app-debug.apk` on your phone.
5. For a stable direct APK link and persistent upgrades, configure release signing and run with `release=true` and `publish=true`.

Workflow artifacts require a GitHub login and are ZIPs. A public repository's **GitHub Release asset** gives the direct phone-download URL described below.

GitHub Actions availability/quotas depend on your GitHub account. The project itself uses no paid libraries or APIs.

## Build locally

Install JDK 17, Android SDK Platform 36 and Android Build Tools 35.0.0. Android Studio can install these SDK components, but the phone does not need Android Studio.

Set `ANDROID_HOME` to your Android SDK directory, or create untracked `local.properties`:

```properties
sdk.dir=/absolute/path/to/Android/Sdk
```

macOS/Linux:

```sh
chmod +x gradlew
./gradlew assembleDebug
./gradlew testDebugUnitTest lintDebug
```

Windows PowerShell:

```powershell
.\gradlew.bat assembleDebug
```

Debug output: `app/build/outputs/apk/debug/app-debug.apk`.

The included `gradlew` is a source-only bootstrap launcher: it uses installed Gradle 8.13 or downloads its official distribution and verifies the published SHA-256 over HTTPS. `gradlew.bat` provides equivalent PowerShell bootstrapping. No fake wrapper JAR is included. With Gradle available, `gradle wrapper --gradle-version 8.13` can generate the conventional wrapper files for committing to your repository.

Dependencies are pinned (AGP 8.13.2, Kotlin 2.1.20, Media3 1.6.1, Room 2.7.1); SDK 36 is a compatible selected target, not a claim about the newest Android release at future build time.

## Release signing and updates

Create your own release key **once**, outside the repository:

```sh
keytool -genkeypair -v -keystore "$HOME/svara-release.jks" -alias svara \
  -keyalg RSA -keysize 3072 -validity 10000
```

Keep the keystore/passwords backed up privately. Reusing this signing key is required for future in-place updates. Do not commit it, share it publicly, or generate a new key for every build.

Set the following environment variables using your shell's secure input or secret manager:

```text
SVARA_KEYSTORE=/absolute/path/to/svara-release.jks
SVARA_STORE_PASSWORD=<your keystore password>
SVARA_KEY_ALIAS=svara
SVARA_KEY_PASSWORD=<your key password>
```

Then:

```sh
./gradlew assembleRelease
```

Output: `app/build/outputs/apk/release/app-release.apk`. A release with no signing configuration is deliberately rejected, not silently signed as debug.

For a configured update URL:

```sh
./gradlew assembleRelease -PUPDATE_URL=https://YOUR-DOMAIN/download/version.json
```

For GitHub Actions add repository **Secrets**:

- `KEYSTORE_BASE64`: the base64-encoded keystore, with no extra wrapping text.
- `KEYSTORE_PASSWORD`, `KEY_PASSWORD`, `KEY_ALIAS`.

Optional repository **Variables**:

- `UPDATE_URL`: e.g. `https://github.com/OWNER/REPO/releases/latest/download/version.json`.
- `PUBLIC_BASE_URL`: your HTTPS download folder; defaults to the current repository's latest GitHub Release assets.

Increase `versionCode` and `versionName` in `app/build.gradle.kts` for each release. Updates are offered only for a greater version code, use HTTPS on the configured metadata host, and open the official APK URL in the browser. Android validates the install/update signature. There is no silent install permission.

Debug and release use different application IDs, so they install separately and do not share data. Avoid keeping both on a phone with limited storage. CI debug signing keys are not a stable upgrade identity; use the release key for ongoing personal use.

## Direct mobile download / Hostinger

After a signed build, package the **actual APK**:

```sh
python3 scripts/package-release.py \
  --apk app/build/outputs/apk/release/app-release.apk \
  --base-url https://YOUR-DOMAIN/download \
  --aapt "$ANDROID_HOME/build-tools/35.0.0/aapt"
```

This extracts the actual app version from the APK, copies it as `music-app-release.apk`, measures its size, and generates `version.json`, `SHA256SUMS` and release notes. No fabricated APK size/version is displayed.

Upload the generated `distribution/` contents to your server's `public_html/download/`. Apache `.htaccess` is included; `mod_headers` must be available. If your host rejects that directive, remove only the Header rules or configure the equivalent server headers.

Phone download link:

```text
https://YOUR-DOMAIN/download/music-app-release.apk
```

Optional landing page:

```text
https://YOUR-DOMAIN/download/
```

GitHub public release URL:

```text
https://github.com/OWNER/REPO/releases/latest/download/music-app-release.apk
```

Open the link on the phone → download → open APK → allow “Install unknown apps” for that browser/file manager → install. Some browsers honor `Content-Disposition` for direct download while others open a download prompt. The app itself does not install anything silently.

No public hosting has been created, no repository modified, and no APK link is live as part of this source delivery. The download page intentionally stays disabled until real `version.json` and an APK are uploaded. Do not rename `version.example.json` to `version.json`; use the packaging script after a real build.

## Project map

```text
app/src/main/java/com/svara/lite/
  data/api/             MusicProvider, Audius, Jamendo, Retrofit service
  data/database/        Room entities, DAO and database
  data/repository/      Search, device music, settings, connectivity
  domain/model/         Song and storage policy
  player/               MediaSessionService, controller, bounded cache
  downloads/            WorkManager worker and native AAC conversion
  ui/home/              Home
  ui/search/            Provider search
  ui/library/           Favorites, playlists, device music and cache
  ui/downloads/         Downloads, progress, failures and sorting
  ui/settings/          Storage, provider settings and updates
```

## Required validation on an Android build machine / phone

`BUILD-STATUS.md` records what was checked here. Before relying on this app:

1. Run `testDebugUnitTest`, `lintDebug`, `assembleDebug`, then signed `assembleRelease`. Verify with `apksigner verify --verbose` and inspect the actual size.
2. Install on Android 8 and a current Android device. Check small screens, large fonts and permission refusal.
3. Configure your provider keys. Search title, artist and genre; verify unavailable-provider messages and stream-only tracks.
4. Play a queue; lock the screen; switch apps; check notification/lock-screen previous/play/next, audio focus, headset removal, seek, shuffle and repeat.
5. Save an allowed track at each bitrate; inspect actual output duration/bitrate, play in airplane mode, and confirm streaming-only tracks cannot download.
6. Exercise budget/full-disk rejection, unknown source length, duplicate taps, network loss, work cancellation, process death and unsupported audio. Ensure no unintended file remains or favorite/playlist row is lost.
7. Test cache off and each limit. Confirm partial caches are not listed as complete offline tracks and clearing cache never removes device music/downloads.
8. Create/rename/delete playlists and reuse one downloaded song in several playlists. Check favorite toggles across search/library.
9. Publish a second APK with the same signing key and incremented version code; verify the update prompt and data-preserving manual installation.

Known practical limits: WorkManager jobs are bounded by Android's execution time and can be deferred/restarted by the OS; very long tracks or slow conversions may not finish. Aggressive OEM battery settings can interrupt background services. The app does not persist a playback queue across process death. Only the selected online track is refreshed immediately before play, so very long queues with expiring provider URLs may need reselecting a track. These need device testing, not a promise of universal behavior.
