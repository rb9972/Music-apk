plugins {
 id("com.android.application") version "8.13.2" apply false
 id("org.jetbrains.kotlin.android") version "2.1.20" apply false
 id("org.jetbrains.kotlin.plugin.compose") version "2.1.20" apply false
 id("org.jetbrains.kotlin.kapt") version "2.1.20" apply false
}
